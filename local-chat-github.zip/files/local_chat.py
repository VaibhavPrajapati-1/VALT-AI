"""
Local Chat - a ChatGPT/Claude-style desktop chat for Ollama models.

Setup:   pip install PySide6 requests      (Python 3.9 or newer)
Run:     python local_chat.py      (Ollama must be running)

Optional extras:
    pip install pypdf                          PDF attachments
    pip install faster-whisper sounddevice     voice input (microphone button)

Features
  * Streaming replies with a Stop button (Send turns into Stop while generating)
  * Multiple saved conversations; pin, rename, delete (right-click); search across all chats
  * Edit & resend any of your messages - old versions stay as branches (< 2/3 >)
  * Short-term memory (last N messages) + long-term memory FILE (memory.md)
  * Context meter + automatic summary of older messages when the window fills up
  * Code blocks with syntax highlighting, Copy / Save-as-file / Run (Python, with confirmation)
  * Personas / projects: saved system prompts with pinned files and optional own memory
  * Thinking display (collapsible) for reasoning models such as Qwen3 / DeepSeek-R1
  * Web search (DuckDuckGo, no API key) - tick "Web" before sending
  * Read replies aloud (Windows built-in speech), optional microphone input
  * Create files: save a code block, or save a whole reply as .md / .txt / .html / .docx
  * Attachments: images (vision models), PDFs, DOCX, text/code - button, drag & drop, paste
  * Dark / light themes, adjustable font size, keyboard shortcuts (Ctrl+/ for the list)
  * Recall of relevant excerpts from older chats, model picker, regenerate, export

Chat commands: /remember /forget /memory /clear /summarize /persona <name> /web <question> /help
Data (chats.json, memory.md, settings.json, personas.json) lives in ~/.local_chat
(override with the LOCAL_CHAT_DIR env var; OLLAMA_URL points to a non-default Ollama server).
Licensed under the MIT License - see LICENSE.
"""
import base64
import html
import ipaddress
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
import uuid
import zipfile
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

try:
    import requests
    from PySide6.QtCore import Qt, QThread, QTimer, QUrl, Signal
    from PySide6.QtGui import QDesktopServices, QGuiApplication, QImage, QKeySequence, QShortcut, QTextCursor
    from PySide6.QtWidgets import (
        QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
        QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout, QInputDialog,
        QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMenu,
        QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QSpinBox,
        QSplitter, QTabWidget, QTextBrowser, QVBoxLayout, QWidget,
    )
except ImportError as _err:        # a friendly message instead of a traceback
    sys.exit(f"Missing Python package: {(_err.name or 'PySide6').split('.')[0]}\n"
             "Install the requirements with:  pip install PySide6 requests")

__version__ = "1.0.0"

OLLAMA = os.environ.get("OLLAMA_URL", "http://localhost:11434")
DATA_DIR = Path(os.environ.get("LOCAL_CHAT_DIR", Path.home() / ".local_chat"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
ATTACH_DIR = DATA_DIR / "attachments"
ATTACH_DIR.mkdir(exist_ok=True)
RUN_DIR = DATA_DIR / "run"
RUN_DIR.mkdir(exist_ok=True)
CHATS_FILE = DATA_DIR / "chats.json"
MEMORY_FILE = DATA_DIR / "memory.md"
LEGACY_MEMORY_FILE = DATA_DIR / "memory.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
PERSONAS_FILE = DATA_DIR / "personas.json"

DEFAULT_SETTINGS = {
    "model": "qwen2.5-coder:7b",
    "system_prompt": (
        "You are a helpful, concise assistant. Use Markdown for formatting "
        "and put code in fenced code blocks."
    ),
    "temperature": 0.7,
    "num_ctx": 4096,      # context window sent to Ollama (bigger = more RAM)
    "max_history": 20,    # how many recent messages to send as context
    "use_memory": True,
    "auto_extract": True,   # extra short model call after each reply to save new facts
    "recall_past": True,    # pull relevant excerpts from older chats into the prompt
    "unload_on_switch": True,   # free the previous model's RAM when you switch models
    "keep_alive": "5m",         # how long Ollama keeps a model in RAM after a reply
    "theme": "dark",
    "font_size": 15,
    "auto_summary": True,       # summarize older messages when the context window fills up
    "show_thinking": True,      # let reasoning models think (and show it, collapsed)
    "allow_run": True,          # show a Run button on Python code blocks (always asks first)
    "web_pages": True,          # web search also reads the top pages, not just snippets
    "speak_replies": False,     # read every finished reply aloud
    "auto_title": False,        # ask the model for a short chat title (one extra call)
    "last_persona": "",
}

KEEP_ALIVE_CHOICES = [
    ("1 minute", "1m"),
    ("5 minutes (Ollama default)", "5m"),
    ("30 minutes", "30m"),
    ("Until Ollama quits", "-1"),
]


def ka_value(v):
    return -1 if v == "-1" else v    # Ollama wants a number for "forever"


MEMORY_INSTRUCTIONS = (
    "\n\nYou have a persistent memory file shared by all chats; its current contents "
    "are listed below. When the user shares something worth keeping long-term (name, "
    "background, preferences, projects, goals, decisions, tools), save it by writing "
    "<memory>one short fact</memory> at the very end of your reply, one tag per fact, "
    "after your normal answer. If the user asks you to forget something, write "
    "<forget>a few words from that fact</forget>. Never mention these tags and never "
    "save trivial or temporary details."
)
EXTRACT_PROMPT = (
    "You maintain a long-term memory file about the user. From the user's message, "
    "list NEW durable facts worth remembering (name, background, skills, preferences, "
    "projects, goals, decisions, tools, hardware). Reply ONLY with lines starting "
    "with '- ', each a short third-person fact like '- User is learning Rust'. "
    "Ignore questions, code, temporary tasks and anything already known. "
    "If there is nothing worth saving, reply exactly NONE."
)
SUMMARY_PROMPT = (
    "You compress a conversation so it can continue with less context. Write a compact "
    "summary (at most 200 words) of the conversation so far: the user's goals, key facts, "
    "decisions, names, file names, and any code or numbers that matter. Plain text, no "
    "preamble. If a previous summary is given, merge it with the new messages."
)
TITLE_PROMPT = ("Write a title of at most 5 words for this conversation. "
                "Reply with the title only, no quotes or punctuation at the end.")
WEB_INSTRUCTIONS = (
    "Web search results are provided below. Use them to answer, say which source (URL) "
    "each fact comes from, and say so if the results don't contain the answer."
)
STOPWORDS = set(
    "the and for are but not you your with that this have from they will would there "
    "their what about which when were been into than then them these those just like "
    "also some can could should how why who where does did its dont want need make "
    "please thanks thank hello give tell show help using use".split()
)

# ------------------------------------------------------------------ themes
THEMES = {
    "dark": dict(bg="#1e1f22", panel="#2b2d31", border="#3a3d42", text="#e6e6e6",
                 muted="#9aa0a6", btn="#3a3d42", btn_hover="#4a4e55", accent="#4f7cff",
                 sel="#3b4a6b", danger="#d9534f", code_bg="#16171a", code_head="#25272c",
                 quote="#2f3238", user_bg="#262a36", link="#7aa2ff",
                 c_kw="#c678dd", c_str="#98c379", c_num="#d19a66", c_com="#7f848e",
                 c_fn="#61afef", c_ty="#e5c07b", c_op="#56b6c2"),
    "light": dict(bg="#f6f6f7", panel="#ffffff", border="#d4d6da", text="#202124",
                  muted="#5f6368", btn="#e3e5e8", btn_hover="#d3d6db", accent="#2f62e8",
                  sel="#cfdcff", danger="#d9534f", code_bg="#f0f1f3", code_head="#e2e4e8",
                  quote="#eceef1", user_bg="#e8eefc", link="#1a56db",
                  c_kw="#a626a4", c_str="#2e7d32", c_num="#b45309", c_com="#8a8f98",
                  c_fn="#1d5fd6", c_ty="#a16207", c_op="#0e7490"),
}


def make_style(t, fs):
    return f"""
QWidget {{ background:{t['bg']}; color:{t['text']}; font-size:{max(fs - 1, 10)}px; }}
QTextBrowser, QPlainTextEdit, QLineEdit, QListWidget, QComboBox,
QSpinBox, QDoubleSpinBox {{ background:{t['panel']}; border:1px solid {t['border']};
    border-radius:6px; padding:6px; }}
QTextBrowser {{ font-size:{fs}px; padding:12px; }}
QListWidget::item {{ padding:8px; border-radius:6px; }}
QListWidget::item:selected {{ background:{t['sel']}; color:{t['text']}; }}
QPushButton {{ background:{t['btn']}; border:none; border-radius:6px; padding:8px 14px; }}
QPushButton:hover {{ background:{t['btn_hover']}; }}
QPushButton:disabled {{ color:{t['muted']}; }}
QPushButton[mode="send"] {{ background:{t['accent']}; color:white; font-weight:bold; }}
QPushButton[mode="stop"] {{ background:{t['danger']}; color:white; font-weight:bold; }}
QPushButton[rec="1"] {{ background:{t['danger']}; color:white; }}
QCheckBox {{ background:transparent; spacing:8px; }}
QCheckBox::indicator {{ width:16px; height:16px; border:1px solid {t['muted']}; border-radius:4px;
    background:{t['panel']}; }}
QCheckBox::indicator:hover {{ border-color:{t['accent']}; }}
QCheckBox::indicator:checked {{ background:{t['accent']}; border:1px solid {t['accent']}; }}
QComboBox QAbstractItemView {{ background:{t['panel']}; }}
QSplitter::handle {{ background:{t['panel']}; }}
QProgressBar {{ border:1px solid {t['border']}; border-radius:5px; background:{t['panel']};
    text-align:center; min-height:16px; max-height:16px; font-size:11px; }}
QProgressBar::chunk {{ background:{t['accent']}; border-radius:4px; }}
QProgressBar[warn="1"]::chunk {{ background:#e0a030; }}
QProgressBar[warn="2"]::chunk {{ background:{t['danger']}; }}
QToolTip {{ background:{t['panel']}; color:{t['text']}; border:1px solid {t['border']}; }}
"""


# ----------------------------------------------------------------- helpers
STARTUP_NOTES = []          # shown once after the window opens (e.g. recovered data)


def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return default
    except Exception:
        # unreadable / corrupt file: keep a copy instead of silently overwriting it on the next save
        try:
            backup = path.with_name(f"{path.name}.corrupt-{time.strftime('%Y%m%d-%H%M%S')}")
            shutil.copy2(path, backup)
            STARTUP_NOTES.append(f"{path.name} couldn't be read, so a copy was saved as "
                                 f"{backup.name} (in {path.parent}). Starting with an empty one.")
        except OSError:
            pass
        return default


def _as_list(x):
    return x if isinstance(x, list) else []


def save_json(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def escape_md(text):
    """Show the user's text literally (no accidental headings/lists)."""
    text = re.sub(r"([\\`*_{}\[\]()#+\-.!|>~<])", r"\\\1", text)
    return text.replace("\n", "  \n")


TAG_RE = re.compile(r"<(memory|forget)>(.*?)</\1>", re.S | re.I)
OPEN_TAG_RE = re.compile(r"<(?:memory|forget)>.*$", re.S | re.I)


def strip_tags(text):
    """Remove <memory>/<forget> tags (also half-streamed ones) from a reply."""
    return OPEN_TAG_RE.sub("", TAG_RE.sub("", text)).rstrip()


_NEUTRALIZE_RE = re.compile(r"<(/?)(memory|forget|think)>", re.I)


def neutralize(text):
    """Defuse <memory>/<forget>/<think> tags inside untrusted text (web pages, files, code output)
    so it cannot write to the memory file. Length is preserved."""
    return _NEUTRALIZE_RE.sub(lambda m: f"\u2039{m.group(1)}{m.group(2)}\u203a", text)


def split_think(text):
    """Split inline <think>...</think> out of a reply -> (thinking, answer, still_thinking)."""
    if "<think>" not in text.lower() and "</think>" not in text.lower():
        return "", text, False
    thoughts, out, pos, open_ = [], [], 0, False
    low = text.lower()
    while True:
        a = low.find("<think>", pos)
        if a < 0:
            tail = text[pos:]
            # some models only emit the closing tag
            b = tail.lower().find("</think>")
            if b >= 0 and not out and not thoughts:
                thoughts.append(tail[:b])
                tail = tail[b + 8:]
            out.append(tail)
            break
        out.append(text[pos:a])
        b = low.find("</think>", a + 7)
        if b < 0:
            thoughts.append(text[a + 7:])
            open_ = True
            break
        thoughts.append(text[a + 7:b])
        pos = b + 8
    return "\n\n".join(t.strip() for t in thoughts if t.strip()), "".join(out).strip(), open_


def save_memories_to(path, items):
    tmp = path.with_suffix(".tmp")
    body = "\n".join(f"- {m}" for m in items)
    tmp.write_text("# Memory\n\n" + body + "\n", encoding="utf-8")
    tmp.replace(path)


def save_memories(items):
    save_memories_to(MEMORY_FILE, items)


def parse_memory_text(text):
    out = []
    for line in text.splitlines():
        line = re.sub(r"^[-*]\s+", "", line.strip())
        if line and not line.startswith("#"):
            out.append(line)
    return out


def load_memories():
    """memory.md: one fact per line; '#' lines ignored; leading '- ' optional."""
    if not MEMORY_FILE.exists() and LEGACY_MEMORY_FILE.exists():
        old = load_json(LEGACY_MEMORY_FILE, [])
        if isinstance(old, list):
            save_memories([str(x) for x in old])
    try:
        text = MEMORY_FILE.read_text(encoding="utf-8")
    except Exception:
        return []
    return parse_memory_text(text)


def tokens(text):
    return {w for w in re.findall(r"[a-zA-Z0-9_+#]{3,}", text.lower()) if w not in STOPWORDS}


def est_tokens(text):
    """Rough token estimate (~3.5 characters per token)."""
    return int(len(text) / 3.5) + 1


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}
MAX_PENDING = 8


def store_image(img, name):
    """Save a model-sized copy (<=1024px) and a thumbnail (<=320px) of a QImage."""
    uid = uuid.uuid4().hex
    ext = "png" if img.hasAlphaChannel() else "jpg"

    def fit(i, n):
        if max(i.width(), i.height()) <= n:
            return i
        return i.scaled(n, n, Qt.KeepAspectRatio, Qt.SmoothTransformation)

    full, thumb = ATTACH_DIR / f"{uid}.{ext}", ATTACH_DIR / f"{uid}_t.{ext}"
    if not (fit(img, 1024).save(str(full)) and fit(img, 320).save(str(thumb))):
        raise ValueError(f"{name}: couldn't process this image")
    return {"name": name, "kind": "image", "path": str(full), "thumb": str(thumb)}


def docx_text(path):
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8", "replace")
    xml = xml.replace("</w:p>", "\n").replace("<w:tab/>", "\t")
    xml = re.sub(r"<w:br[^>]*/>", "\n", xml)
    return html.unescape(re.sub(r"<[^>]+>", "", xml))


def pdf_text(path, limit):
    try:
        from pypdf import PdfReader
    except ImportError:
        raise ValueError("PDF support needs one extra package:  pip install pypdf")
    out, size = [], 0
    for i, page in enumerate(PdfReader(str(path)).pages):
        t = (page.extract_text() or "").strip()
        if t:
            out.append(f"[Page {i + 1}]\n{t}")
            size += len(t)
        if size > limit:
            break
    return "\n\n".join(out)


def make_attachment(path, cap):
    """Turn a file into an attachment dict. Raises ValueError with a friendly message."""
    p = Path(path)
    name, ext = p.name, p.suffix.lower()
    if not p.is_file():
        raise ValueError(f"{name}: not a file")
    if ext in IMAGE_EXTS:
        img = QImage(str(p))
        if img.isNull():
            raise ValueError(f"{name}: couldn't read this image")
        return store_image(img, name)
    try:
        if ext == ".pdf":
            text = pdf_text(p, cap)
        elif ext == ".docx":
            text = docx_text(p)
        else:
            if p.stat().st_size > 50 * 1024 * 1024:
                raise ValueError(f"{name}: file is too large (50 MB max)")
            with open(p, "rb") as f:
                raw = f.read(cap * 4 + 1)
            if b"\x00" in raw[:4096]:
                raise ValueError(f"{name}: this file type isn't supported "
                                 "(images, PDF, DOCX and text/code files work)")
            text = raw.decode("utf-8", errors="replace")
    except ValueError:
        raise
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"{name}: couldn't read it ({e.__class__.__name__})")
    text = text.strip()
    if not text:
        raise ValueError(f"{name}: no readable text found (a scanned PDF?)")
    return {"name": name, "kind": "text", "text": text[:cap],
            "truncated": len(text) > cap, "chars": len(text)}


# ------------------------------------------------- syntax highlighting (no deps)
KEYWORDS = {
    "python": "and as assert async await break class continue def del elif else except finally for "
              "from global if import in is lambda nonlocal not or pass raise return try while with "
              "yield None True False self match case",
    "js": "async await break case catch class const continue debugger default delete do else export "
          "extends finally for function if import in instanceof let new of return static super switch "
          "this throw try typeof var void while with yield null undefined true false",
    "c": "alignas auto break case catch class const constexpr continue default delete do else enum "
         "explicit extern for friend goto if inline namespace new noexcept nullptr operator private "
         "protected public register return sizeof static struct switch template this throw try "
         "typedef typename union using virtual volatile while true false NULL override final",
    "java": "abstract assert boolean break byte case catch char class const continue default do double "
            "else enum extends final finally float for if implements import instanceof int interface "
            "long native new package private protected public return short static super switch "
            "synchronized this throw throws try void volatile while null true false var record",
    "rust": "as async await break const continue crate dyn else enum extern false fn for if impl in let "
            "loop match mod move mut pub ref return self Self static struct super trait true type "
            "unsafe use where while",
    "go": "break case chan const continue default defer else fallthrough for func go goto if import "
          "interface map package range return select struct switch type var nil true false",
    "gd": "and as assert await break class class_name const continue elif else enum export extends for "
          "func if in is match not onready or pass preload return setget signal static super tool var "
          "void while yield null true false self",
    "sql": "select from where insert into values update set delete create table drop alter add join "
           "left right inner outer on group by order having limit as and or not null is in like "
           "distinct union primary key foreign references index count sum avg min max",
    "sh": "if then else elif fi for while do done case esac function in return exit echo export "
          "local cd ls rm cp mv mkdir cat grep sed awk set unset source",
    "json": "true false null",
}
LANG_ALIASES = {
    "py": "python", "python3": "python", "python": "python",
    "js": "js", "javascript": "js", "ts": "js", "typescript": "js", "jsx": "js", "tsx": "js",
    "c": "c", "cpp": "c", "c++": "c", "cc": "c", "h": "c", "hpp": "c", "cs": "java", "csharp": "java",
    "java": "java", "kotlin": "java", "kt": "java", "php": "js",
    "rust": "rust", "rs": "rust", "go": "go", "golang": "go",
    "gdscript": "gd", "gd": "gd", "sql": "sql",
    "bash": "sh", "sh": "sh", "shell": "sh", "zsh": "sh", "powershell": "sh", "ps1": "sh",
    "json": "json",
}
LANG_EXT = {
    "python": "py", "py": "py", "js": "js", "javascript": "js", "typescript": "ts", "ts": "ts",
    "c": "c", "cpp": "cpp", "c++": "cpp", "h": "h", "hpp": "hpp", "java": "java", "cs": "cs",
    "csharp": "cs", "rust": "rs", "go": "go", "gdscript": "gd", "gd": "gd", "sql": "sql",
    "bash": "sh", "sh": "sh", "shell": "sh", "powershell": "ps1", "html": "html", "css": "css",
    "json": "json", "yaml": "yml", "yml": "yml", "xml": "xml", "markdown": "md", "md": "md",
    "toml": "toml", "ini": "ini", "csv": "csv", "kotlin": "kt", "php": "php", "ruby": "rb",
    "lua": "lua", "swift": "swift", "text": "txt", "txt": "txt", "": "txt",
}
_COMMENT = {
    "python": r"#[^\n]*", "sh": r"#[^\n]*", "gd": r"#[^\n]*",
    "sql": r"--[^\n]*|/\*.*?\*/",
    "c": r"//[^\n]*|/\*.*?\*/|(?m:^[ \t]*\#[^\n]*)",
    "js": r"//[^\n]*|/\*.*?\*/", "java": r"//[^\n]*|/\*.*?\*/",
    "rust": r"//[^\n]*|/\*.*?\*/", "go": r"//[^\n]*|/\*.*?\*/",
    "json": r"(?!x)x",                                    # JSON has no comments
    None: r"#[^\n]*|//[^\n]*|--[^\n]*|/\*.*?\*/",
}
_TOKEN_CACHE = {}


def _token_re(key):
    if key not in _TOKEN_CACHE:
        _TOKEN_CACHE[key] = re.compile(
            r"(?P<com>" + _COMMENT.get(key, _COMMENT[None]) + r")"
            r"|(?P<str>\"\"\".*?\"\"\"|\'\'\'.*?\'\'\'|\"(?:\\.|[^\"\\\n])*\"|\'(?:\\.|[^\'\\\n])*\'"
            r"|`(?:\\.|[^`\\])*`)"
            r"|(?P<num>\b0x[0-9a-fA-F]+\b|\b\d+(?:\.\d+)?\b)"
            r"|(?P<word>[A-Za-z_][A-Za-z_0-9]*)", re.S)
    return _TOKEN_CACHE[key]


def highlight(code, lang, t):
    """Return HTML (spans with inline colors) for a code string."""
    key = LANG_ALIASES.get((lang or "").lower().strip())
    kws = set(KEYWORDS.get(key, "").split()) if key else set()
    out, pos = [], 0
    for m in _token_re(key).finditer(code):
        out.append(html.escape(code[pos:m.start()]))
        pos = m.end()
        kind, s = m.lastgroup, m.group()
        if kind == "com":
            if key == "c" and s.lstrip().startswith("#"):       # #include, #define ...
                out.append(f'<span style="color:{t["c_op"]}">{html.escape(s)}</span>')
            else:
                out.append(f'<span style="color:{t["c_com"]}"><i>{html.escape(s)}</i></span>')
        elif kind == "str":
            out.append(f'<span style="color:{t["c_str"]}">{html.escape(s)}</span>')
        elif kind == "num":
            out.append(f'<span style="color:{t["c_num"]}">{html.escape(s)}</span>')
        else:
            if s in kws:
                out.append(f'<span style="color:{t["c_kw"]}">{html.escape(s)}</span>')
            elif code[pos:pos + 1] == "(":
                out.append(f'<span style="color:{t["c_fn"]}">{html.escape(s)}</span>')
            elif s[:1].isupper() and key not in (None, "json", "sql"):
                out.append(f'<span style="color:{t["c_ty"]}">{html.escape(s)}</span>')
            else:
                out.append(html.escape(s))
    out.append(html.escape(code[pos:]))
    return "".join(out)


# ------------------------------------------------------- markdown -> HTML
FENCE_RE = re.compile(r"^```[ \t]*([^\n`]*)\n(.*?)(?:^```[ \t]*$|\Z)", re.S | re.M)


def find_code_blocks(text):
    """All fenced blocks in order -> [(lang, code, closed)]. Used by the renderer AND the buttons."""
    out = []
    for m in FENCE_RE.finditer(text):
        lang = (m.group(1).strip().split() or [""])[0].lower()
        closed = m.group(0).rstrip().endswith("```") and len(m.group(0).strip()) > 3 + len(m.group(1).strip())
        code = m.group(2)
        if closed and code.endswith("\n"):
            code = code[:-1]
        out.append((lang, code, closed))
    return out


def _inline(text, t):
    """Inline markdown: code, bold, italic, links."""
    parts = re.split(r"(`[^`\n]+`)", text)
    res = []
    for i, p in enumerate(parts):
        if i % 2 == 1:
            res.append(f'<span style="background:{t["code_bg"]}; font-family:Consolas,monospace; '
                       f'color:{t["c_str"]}">&nbsp;{html.escape(p[1:-1])}&nbsp;</span>')
            continue
        p = html.escape(p, quote=False)
        p = re.sub(r"\[([^\]]+)\]\((https?://[^)\s]+)\)",
                   lambda m: f'<a href="{m.group(2).replace(chr(34), "%22")}" style="color:{t["link"]}">{m.group(1)}</a>', p)
        p = re.sub(r"(?<![\"=>\w])(https?://[^\s<)]+)",
                   lambda m: f'<a href="{m.group(1).replace(chr(34), "%22")}" style="color:{t["link"]}">{m.group(1)}</a>', p)
        p = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", p)
        p = re.sub(r"__(.+?)__", r"<b>\1</b>", p)
        p = re.sub(r"(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])", r"<i>\1</i>", p)
        p = re.sub(r"(?<![\w_])_(?!\s)(.+?)(?<!\s)_(?![\w_])", r"<i>\1</i>", p)
        p = re.sub(r"~~(.+?)~~", r"<s>\1</s>", p)
        res.append(p)
    return "".join(res)


def code_block_html(code, lang, t, links=None):
    """links: list of (label, href) shown in the header bar."""
    label = html.escape(lang or "code")
    bar = ""
    if links:
        bar = " &nbsp;&nbsp; ".join(
            f'<a href="{h}" style="color:{t["link"]}; text-decoration:none">{html.escape(l)}</a>'
            for l, h in links)
    body = highlight(code, lang, t).replace("\n", "<br>").replace("  ", "&nbsp; ").replace("\t", "&nbsp;&nbsp;&nbsp;&nbsp;")
    return (f'<table width="100%" cellspacing="0" cellpadding="6" style="margin-top:6px; margin-bottom:6px">'
            f'<tr><td bgcolor="{t["code_head"]}"><span style="color:{t["muted"]}">{label}</span>'
            f'<span style="color:{t["muted"]}">&nbsp;&nbsp;|&nbsp;&nbsp;</span>{bar}</td></tr>'
            f'<tr><td bgcolor="{t["code_bg"]}"><span style="font-family:Consolas,\'Courier New\',monospace; '
            f'font-size:13px">{body}</span></td></tr></table>')


def markdown_html(text, t, block_links=None, start_block=0):
    """Small Markdown renderer for QTextBrowser. block_links(i, lang, code, closed) -> links list.
    Returns (html, next_block_index)."""
    blocks = list(FENCE_RE.finditer(text))
    out, pos, bi = [], 0, start_block

    def prose(chunk):
        out.append(_prose(chunk, t))

    for m in blocks:
        prose(text[pos:m.start()])
        lang = (m.group(1).strip().split() or [""])[0].lower()
        closed = m.group(0).rstrip().endswith("```") and len(m.group(0).strip()) > 3 + len(m.group(1).strip())
        code = m.group(2)
        if closed and code.endswith("\n"):
            code = code[:-1]
        links = block_links(bi, lang, code, closed) if block_links and closed else None
        out.append(code_block_html(code, lang, t, links))
        bi += 1
        pos = m.end()
    prose(text[pos:])
    return "".join(out), bi


def _prose(chunk, t):
    lines = chunk.split("\n")
    out, i, n = [], 0, len(lines)
    para = []

    def flush():
        if para:
            out.append("<p style='margin-top:4px; margin-bottom:4px'>" +
                       "<br>".join(_inline(x, t) for x in para) + "</p>")
            para.clear()

    while i < n:
        line = lines[i]
        s = line.strip()
        if not s:
            flush(); i += 1; continue
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            flush()
            size = {1: 22, 2: 19, 3: 17}.get(len(m.group(1)), 15)
            out.append(f"<p style='margin-top:10px; margin-bottom:4px'><b><span style='font-size:{size}px'>"
                       f"{_inline(m.group(2), t)}</span></b></p>")
            i += 1; continue
        if re.match(r"^([-*_])(\s*\1){2,}$", s):
            flush(); out.append("<hr>"); i += 1; continue
        if s.startswith(">"):
            flush()
            q = []
            while i < n and lines[i].strip().startswith(">"):
                q.append(lines[i].strip()[1:].strip()); i += 1
            out.append(f'<table width="100%" cellpadding="6" cellspacing="0"><tr><td bgcolor="{t["quote"]}">'
                       f'<span style="color:{t["muted"]}">{"<br>".join(_inline(x, t) for x in q)}</span></td></tr></table>')
            continue
        if re.match(r"^\s*([-*+]|\d+[.)])\s+", line):
            flush()
            ordered = bool(re.match(r"^\s*\d+[.)]\s+", line))
            items = []
            while i < n and re.match(r"^\s*([-*+]|\d+[.)])\s+", lines[i]):
                indent = len(lines[i]) - len(lines[i].lstrip())
                body = re.sub(r"^\s*([-*+]|\d+[.)])\s+", "", lines[i])
                items.append((indent, body)); i += 1
                while i < n and lines[i].strip() and not re.match(r"^\s*([-*+]|\d+[.)])\s+", lines[i]) \
                        and (len(lines[i]) - len(lines[i].lstrip())) > indent:
                    items[-1] = (indent, items[-1][1] + " " + lines[i].strip()); i += 1
            tag = "ol" if ordered else "ul"
            res = [f"<{tag} style='margin-top:2px; margin-bottom:2px'>"]
            base = min(x[0] for x in items)
            cur = 0
            for indent, body in items:
                lvl = min((indent - base) // 2, 4) if indent > base else 0
                while cur < lvl:
                    res.append("<ul>"); cur += 1
                while cur > lvl:
                    res.append("</ul>"); cur -= 1
                res.append(f"<li>{_inline(body, t)}</li>")
            while cur > 0:
                res.append("</ul>"); cur -= 1
            res.append(f"</{tag}>")
            out.append("".join(res))
            continue
        if "|" in s and i + 1 < n and re.match(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$", lines[i + 1]):
            flush()
            def cells(r):
                r = r.strip()
                if r.startswith("|"): r = r[1:]
                if r.endswith("|"): r = r[:-1]
                return [c.strip() for c in r.split("|")]
            head = cells(lines[i]); i += 2
            rows = []
            while i < n and "|" in lines[i] and lines[i].strip():
                rows.append(cells(lines[i])); i += 1
            h = "".join(f'<th bgcolor="{t["code_head"]}" align="left">{_inline(c, t)}</th>' for c in head)
            body = "".join("<tr>" + "".join(f"<td>{_inline(c, t)}</td>" for c in r) + "</tr>" for r in rows)
            out.append(f'<table border="1" cellspacing="0" cellpadding="5" style="border-color:{t["border"]}">'
                       f"<tr>{h}</tr>{body}</table>")
            continue
        para.append(line); i += 1
    flush()
    return "".join(out)


# ------------------------------------------------------------- docx export
def _xml(s):
    s = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", s)
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _runs(text, size=22, mono=False, bold=False):
    """Split **bold** / `code` segments into Word runs."""
    out = []
    for seg in re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
        if not seg:
            continue
        b, m, s = bold, mono, seg
        if seg.startswith("**") and seg.endswith("**") and len(seg) > 4:
            b, s = True, seg[2:-2]
        elif seg.startswith("`") and seg.endswith("`") and len(seg) > 2:
            m, s = True, seg[1:-1]
        rpr = f'<w:sz w:val="{size}"/>'
        if b:
            rpr = "<w:b/>" + rpr
        if m:
            rpr = '<w:rFonts w:ascii="Consolas" w:hAnsi="Consolas" w:cs="Consolas"/>' + rpr
        out.append(f'<w:r><w:rPr>{rpr}</w:rPr><w:t xml:space="preserve">{_xml(s)}</w:t></w:r>')
    return "".join(out)


def write_docx(path, title, md):
    """Minimal .docx writer (no dependencies): headings, bullets, code blocks, paragraphs."""
    paras = []

    def p(runs, ind=0, shade=False, after=120):
        ppr = f'<w:spacing w:after="{after}"/>'
        if ind:
            ppr += f'<w:ind w:left="{ind}"/>'
        if shade:
            ppr += '<w:shd w:val="clear" w:color="auto" w:fill="F0F1F3"/>'
        paras.append(f"<w:p><w:pPr>{ppr}</w:pPr>{runs}</w:p>")

    if title:
        p(_runs(title, size=40, bold=True), after=200)
    in_code = False
    for line in md.split("\n"):
        if line.strip().startswith("```"):
            in_code = not in_code
            continue
        if in_code:
            p(_runs(line or " ", size=20, mono=True), shade=True, after=0)
            continue
        s = line.rstrip()
        if not s.strip():
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            size = {1: 36, 2: 30, 3: 26}.get(len(m.group(1)), 24)
            p(_runs(m.group(2), size=size, bold=True), after=160)
        elif re.match(r"^\s*[-*+]\s+", s):
            p(_runs("\u2022  " + re.sub(r"^\s*[-*+]\s+", "", s)), ind=360)
        elif re.match(r"^\s*\d+[.)]\s+", s):
            p(_runs(s.strip()), ind=360)
        elif s.lstrip().startswith(">"):
            p(_runs(s.lstrip()[1:].strip()), ind=360)
        else:
            p(_runs(s))
    body = "".join(paras) or "<w:p/>"
    document = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
                f'<w:body>{body}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
                '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" '
                'w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>')
    content_types = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                     '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                     '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                     '<Default Extension="xml" ContentType="application/xml"/>'
                     '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-'
                     'officedocument.wordprocessingml.document.main+xml"/></Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
            'relationships/officeDocument" Target="word/document.xml"/></Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", rels)
        z.writestr("word/document.xml", document)


def md_to_plain(text):
    """Markdown -> text suitable for reading aloud."""
    text = re.sub(r"```.*?(```|\Z)", " (code block) ", text, flags=re.S)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"https?://\S+", "link", text)
    text = re.sub(r"[#*_>~|]", "", text)
    return re.sub(r"\s+", " ", text).strip()


# ---------------------------------------------------------------- web search
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"}


def _strip_html(s):
    s = re.sub(r"<[^>]+>", "", s)
    return " ".join(html.unescape(s).split())


def ddg_search(query, n=5):
    """DuckDuckGo HTML endpoint (no API key). Returns [{title,url,snippet}]."""
    r = requests.post("https://html.duckduckgo.com/html/", data={"q": query},
                      headers=UA, timeout=12)
    r.raise_for_status()
    page = r.text
    results = []
    for m in re.finditer(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=<a[^>]+class="result__a"|\Z)',
                         page, re.S):
        href, title, rest = m.group(1), _strip_html(m.group(2)), m.group(3)
        if href.startswith("//"):
            href = "https:" + href
        q = parse_qs(urlparse(href).query)
        if "uddg" in q:
            href = unquote(q["uddg"][0])
        if "duckduckgo.com/y.js" in href:       # ads
            continue
        if not href.startswith(("http://", "https://")):
            continue
        sm = re.search(r'class="result__snippet"[^>]*>(.*?)</a>', rest, re.S)
        results.append({"title": title, "url": href, "snippet": _strip_html(sm.group(1)) if sm else ""})
        if len(results) >= n:
            break
    return results


def _public_http_url(url):
    """http(s) only, and no localhost / private-network addresses (page reading stays on the public web)."""
    u = urlparse(url)
    if u.scheme not in ("http", "https") or not u.hostname:
        return False
    host = u.hostname.lower()
    if host == "localhost" or host.endswith((".local", ".localhost", ".internal")):
        return False
    try:
        return ipaddress.ip_address(host).is_global
    except ValueError:
        return True                                   # a normal host name


def page_text(url, limit=1500):
    """Fetch a page and return its readable text (rough). Reads at most ~1.5 MB."""
    if not _public_http_url(url):
        return ""
    with requests.get(url, headers=UA, timeout=7, stream=True) as r:
        if not _public_http_url(r.url) or "html" not in r.headers.get("content-type", "html"):
            return ""
        raw = b""
        for chunk in r.iter_content(65536):
            raw += chunk
            if len(raw) > 1_500_000:
                break
        fallback_enc = r.encoding or "latin-1"
    try:
        page = raw.decode("utf-8")
    except UnicodeDecodeError:
        page = raw.decode(fallback_enc, errors="replace")
    s = re.sub(r"(?is)<(script|style|noscript|nav|footer|header|svg|form)[^>]*>.*?</\1>", " ", page)
    s = re.sub(r"(?s)<!--.*?-->", " ", s)
    s = re.sub(r"(?i)</(p|div|li|h[1-6]|br|tr)>", "\n", s)
    text = html.unescape(re.sub(r"<[^>]+>", " ", s))
    lines = [" ".join(x.split()) for x in text.split("\n")]
    text = "\n".join(x for x in lines if len(x) > 40)
    return text[:limit]


# ------------------------------------------------------------------ workers
class ChatWorker(QThread):
    """Streams a reply from Ollama's /api/chat in a background thread."""
    token = Signal(int, str)
    thinking = Signal(int, str)
    stats = Signal(int, str)
    usage = Signal(int, int)       # gid, tokens used (prompt + reply)
    failed = Signal(int, str)
    done = Signal(int)

    def __init__(self, gid, model, messages, options, keep_alive="5m", think=None, parent=None):
        super().__init__(parent)
        self.keep_alive = keep_alive
        self.think = think
        self.gid = gid
        self.model = model
        self.messages = messages
        self.options = options
        self._stop = False
        self._resp = None

    def stop(self):
        self._stop = True
        resp = self._resp
        if resp is not None:
            try:
                resp.close()
            except Exception:
                pass

    def run(self):
        payload = {
            "model": self.model,
            "messages": self.messages,
            "stream": True,
            "options": self.options,
            "keep_alive": ka_value(self.keep_alive),
        }
        if self.think is not None:
            payload["think"] = self.think
        try:
            with requests.post(f"{OLLAMA}/api/chat", json=payload,
                               stream=True, timeout=(5, 900)) as resp:
                self._resp = resp
                if resp.status_code != 200:
                    self.failed.emit(self.gid, f"Ollama error {resp.status_code}: {resp.text[:300]}")
                    return
                for line in resp.iter_lines():
                    if self._stop:
                        break
                    if not line:
                        continue
                    data = json.loads(line)
                    if "error" in data:
                        self.failed.emit(self.gid, data["error"])
                        return
                    msg = data.get("message", {})
                    th = msg.get("thinking", "")
                    if th:
                        self.thinking.emit(self.gid, th)
                    chunk = msg.get("content", "")
                    if chunk:
                        self.token.emit(self.gid, chunk)
                    if data.get("done"):
                        n = data.get("eval_count", 0)
                        ns = data.get("eval_duration", 0)
                        if n and ns:
                            self.stats.emit(self.gid, f"{n / (ns / 1e9):.1f} tokens/s")
                        self.usage.emit(self.gid, int(data.get("prompt_eval_count", 0)) + int(n or 0))
        except requests.exceptions.ConnectionError:
            if not self._stop:
                self.failed.emit(self.gid, "Can't reach Ollama. Is it running?")
        except Exception as e:  # noqa: BLE001
            if not self._stop:
                self.failed.emit(self.gid, str(e))
        finally:
            self.done.emit(self.gid)


class AskWorker(QThread):
    """One short, non-streaming call (fact extraction, summaries, titles)."""
    result = Signal(str, str)      # tag, text

    def __init__(self, tag, model, system, user, options, keep_alive="5m", parent=None):
        super().__init__(parent)
        self.tag, self.model, self.system, self.user = tag, model, system, user
        self.options, self.keep_alive = options, keep_alive

    def run(self):
        try:
            r = requests.post(f"{OLLAMA}/api/chat", json={
                "model": self.model, "stream": False,
                "keep_alive": ka_value(self.keep_alive),
                "messages": [
                    {"role": "system", "content": self.system},
                    {"role": "user", "content": self.user},
                ],
                "options": self.options,
            }, timeout=(5, 600))
            text = r.json().get("message", {}).get("content", "")
            self.result.emit(self.tag, split_think(text)[1])
        except Exception:
            self.result.emit(self.tag, "")


class UnloadWorker(QThread):
    """Frees a model's RAM in Ollama (after any request still using it has ended)."""
    done = Signal(str)

    def __init__(self, model, wait_for, parent=None):
        super().__init__(parent)
        self.model, self.wait_for = model, wait_for

    @staticmethod
    def _norm(name):
        return name if ":" in name else name + ":latest"

    def run(self):
        for t in self.wait_for:
            t.wait(60000)
        try:
            ps = requests.get(f"{OLLAMA}/api/ps", timeout=3).json().get("models", [])
            loaded = {self._norm(m.get("name") or m.get("model") or "") for m in ps}
            if self._norm(self.model) in loaded:
                requests.post(f"{OLLAMA}/api/generate",
                              json={"model": self.model, "keep_alive": 0}, timeout=60)
                self.done.emit(f"Unloaded {self.model} from RAM")
        except Exception:
            pass


class SearchWorker(QThread):
    """Web search + (optionally) reading the top pages."""
    result = Signal(dict)

    def __init__(self, query, read_pages, char_budget, token=0, parent=None):
        super().__init__(parent)
        self.query, self.read_pages, self.budget, self.token = query, read_pages, char_budget, token

    def run(self):
        out = {"query": self.query, "results": [], "context": "", "error": "", "token": self.token}
        try:
            res = ddg_search(self.query, 5)
            out["results"] = res
            if not res:
                out["error"] = "No web results found."
            else:
                parts, used = [], 0
                per_page = max(600, self.budget // 3)
                for i, r in enumerate(res):
                    entry = f"[{i + 1}] {r['title']}\nURL: {r['url']}\n{r['snippet']}"
                    if self.read_pages and i < 2:
                        try:
                            body = page_text(r["url"], per_page)
                            if body:
                                entry += "\nPage text: " + body
                        except Exception:
                            pass
                    if used + len(entry) > self.budget and parts:
                        break
                    parts.append(entry[: self.budget])
                    used += len(entry)
                out["context"] = neutralize("\n\n".join(parts))
        except requests.exceptions.ConnectionError:
            out["error"] = "Web search failed: no internet connection."
        except Exception as e:  # noqa: BLE001
            out["error"] = f"Web search failed ({e.__class__.__name__})."
        self.result.emit(out)


def python_for_snippets():
    """Interpreter for the Run button (sys.executable would be the app itself in a frozen build)."""
    if getattr(sys, "frozen", False):
        return shutil.which("python") or shutil.which("python3") or shutil.which("py")
    return sys.executable


class RunWorker(QThread):
    """Runs a Python snippet in a separate process (30 s limit)."""
    result = Signal(str, int)      # output, exit code (-1 = timed out)

    def __init__(self, code, parent=None):
        super().__init__(parent)
        self.code = code

    def run(self):
        f = RUN_DIR / f"snippet_{uuid.uuid4().hex[:8]}.py"
        try:
            f.write_text(self.code, encoding="utf-8")
            py = python_for_snippets()
            if not py:
                self.result.emit("Couldn't find a Python interpreter on PATH to run this code.", 1)
                return
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = 0x08000000      # no console window
            try:
                p = subprocess.run([py, "-u", str(f)], cwd=str(RUN_DIR),
                                   capture_output=True, text=True, encoding="utf-8",
                                   errors="replace", timeout=30, stdin=subprocess.DEVNULL, **kw)
                out = (p.stdout or "") + (("\n" + p.stderr) if p.stderr else "")
                self.result.emit(out.strip()[-4000:] or "(no output)", p.returncode)
            except subprocess.TimeoutExpired as e:
                partial = (e.stdout or b"")
                if isinstance(partial, bytes):
                    partial = partial.decode("utf-8", "replace")
                self.result.emit((partial.strip()[-3000:] + "\n(stopped: took longer than 30 seconds)").strip(), -1)
        except Exception as e:  # noqa: BLE001
            self.result.emit(f"Couldn't run the code: {e}", 1)
        finally:
            try:
                f.unlink(missing_ok=True)
            except OSError:
                pass


class MicWorker(QThread):
    """Records from the microphone until stop(), then transcribes with faster-whisper (CPU)."""
    text = Signal(str)
    failed = Signal(str)
    status = Signal(str)
    _model = None

    def __init__(self, parent=None):
        super().__init__(parent)
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        try:
            import numpy as np
            import sounddevice as sd
            from faster_whisper import WhisperModel
        except ImportError:
            self.failed.emit("Voice input needs two packages:\n  pip install faster-whisper sounddevice\n"
                             "(Windows also has built-in dictation: press Win+H in the message box.)")
            return
        try:
            frames = []
            with sd.InputStream(samplerate=16000, channels=1, dtype="float32",
                                callback=lambda d, n, t, s: frames.append(d.copy())):
                while not self._stop:
                    self.msleep(80)
            if not frames:
                return
            audio = np.concatenate(frames)[:, 0]
            if len(audio) < 8000:
                self.failed.emit("Recording was too short.")
                return
            self.status.emit("Transcribing...")
            if MicWorker._model is None:
                self.status.emit("Loading speech model (first time downloads ~150 MB)...")
                MicWorker._model = WhisperModel("base", device="cpu", compute_type="int8")
            segs, _info = MicWorker._model.transcribe(audio, vad_filter=True)
            self.text.emit(" ".join(s.text.strip() for s in segs).strip())
        except Exception as e:  # noqa: BLE001
            self.failed.emit(f"Voice input failed: {e}")


# ----------------------------------------------------------------- dialogs
class SettingsDialog(QDialog):
    def __init__(self, s, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        self.resize(560, 560)
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs, 1)

        def page(title):
            w = QWidget()
            f = QFormLayout(w)
            tabs.addTab(w, title)
            return f

        gen = page("General")
        self.prompt = QPlainTextEdit(s["system_prompt"])
        self.temp = QDoubleSpinBox()
        self.temp.setRange(0.0, 2.0)
        self.temp.setSingleStep(0.1)
        self.temp.setValue(s["temperature"])
        self.ctx = QSpinBox()
        self.ctx.setRange(1024, 131072)
        self.ctx.setSingleStep(1024)
        self.ctx.setValue(s["num_ctx"])
        self.hist = QSpinBox()
        self.hist.setRange(2, 200)
        self.hist.setValue(s["max_history"])
        self.theme = QComboBox()
        self.theme.addItem("Dark", "dark")
        self.theme.addItem("Light", "light")
        self.theme.setCurrentIndex(max(0, self.theme.findData(s["theme"])))
        self.font_spin = QSpinBox()
        self.font_spin.setRange(10, 28)
        self.font_spin.setValue(s["font_size"])
        self.unload = QCheckBox("Unload the previous model from RAM when I switch models")
        self.unload.setChecked(s["unload_on_switch"])
        self.keep = QComboBox()
        for label, val in KEEP_ALIVE_CHOICES:
            self.keep.addItem(label, val)
        idx = self.keep.findData(s["keep_alive"])
        self.keep.setCurrentIndex(idx if idx >= 0 else 1)
        gen.addRow("Default system prompt", self.prompt)
        gen.addRow("Temperature", self.temp)
        gen.addRow("Context size (tokens)", self.ctx)
        gen.addRow("Messages of history to send", self.hist)
        gen.addRow("Theme", self.theme)
        gen.addRow("Chat font size", self.font_spin)
        gen.addRow("", self.unload)
        gen.addRow("Keep model in RAM after replying", self.keep)

        mem = page("Memory")
        self.use_mem = QCheckBox("Include long-term memory in every chat")
        self.use_mem.setChecked(s["use_memory"])
        self.auto = QCheckBox("Auto-save new facts after each reply (one extra short call)")
        self.auto.setChecked(s["auto_extract"])
        self.recall = QCheckBox("Recall relevant excerpts from older chats")
        self.recall.setChecked(s["recall_past"])
        self.summary = QCheckBox("Auto-summarize older messages when the context window is ~75% full")
        self.summary.setChecked(s["auto_summary"])
        self.title_chk = QCheckBox("Let the model write a short title for new chats (one extra call)")
        self.title_chk.setChecked(s["auto_title"])
        for w in (self.use_mem, self.auto, self.recall, self.summary, self.title_chk):
            mem.addRow(w)

        fea = page("Features")
        self.think = QCheckBox("Let reasoning models think, and show it (collapsed). Off = faster replies")
        self.think.setChecked(s["show_thinking"])
        self.run_chk = QCheckBox("Show a Run button on Python code blocks (always asks before running)")
        self.run_chk.setChecked(s["allow_run"])
        self.pages = QCheckBox("Web search also reads the top 2 result pages (slower, better answers)")
        self.pages.setChecked(s["web_pages"])
        self.speak = QCheckBox("Read every finished reply aloud automatically")
        self.speak.setChecked(s["speak_replies"])
        for w in (self.think, self.run_chk, self.pages, self.speak):
            fea.addRow(w)

        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        outer.addWidget(box)

    def values(self):
        return {
            "system_prompt": self.prompt.toPlainText().strip(),
            "temperature": self.temp.value(),
            "num_ctx": self.ctx.value(),
            "max_history": self.hist.value(),
            "theme": self.theme.currentData(),
            "font_size": self.font_spin.value(),
            "use_memory": self.use_mem.isChecked(),
            "auto_extract": self.auto.isChecked(),
            "recall_past": self.recall.isChecked(),
            "auto_summary": self.summary.isChecked(),
            "auto_title": self.title_chk.isChecked(),
            "unload_on_switch": self.unload.isChecked(),
            "keep_alive": self.keep.currentData(),
            "show_thinking": self.think.isChecked(),
            "allow_run": self.run_chk.isChecked(),
            "web_pages": self.pages.isChecked(),
            "speak_replies": self.speak.isChecked(),
        }


class MemoryDialog(QDialog):
    def __init__(self, memories, parent=None, title="Long-term memory"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(520, 440)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Facts the model should always know. Double-click to edit."))
        self.list = QListWidget()
        for m in memories:
            self._add_item(m)
        lay.addWidget(self.list)

        row = QHBoxLayout()
        self.entry = QLineEdit()
        self.entry.setPlaceholderText("Add something to remember...")
        self.entry.returnPressed.connect(self.add)
        add = QPushButton("Add")
        add.clicked.connect(self.add)
        delete = QPushButton("Delete selected")
        delete.clicked.connect(self.delete)
        row.addWidget(self.entry, 1)
        row.addWidget(add)
        row.addWidget(delete)
        lay.addLayout(row)

        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        lay.addWidget(box)

    def _add_item(self, text):
        it = QListWidgetItem(text)
        it.setFlags(it.flags() | Qt.ItemIsEditable)
        self.list.addItem(it)

    def add(self):
        text = self.entry.text().strip()
        if text:
            self._add_item(text)
            self.entry.clear()

    def delete(self):
        for it in self.list.selectedItems():
            self.list.takeItem(self.list.row(it))

    def memories(self):
        out = [self.list.item(i).text().strip() for i in range(self.list.count())]
        return [m for m in out if m]


class PersonaDialog(QDialog):
    """Create / edit personas (projects): own prompt, pinned files, optional own memory."""

    def __init__(self, personas, ctx_cap, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Personas / projects")
        self.resize(820, 560)
        self.personas = json.loads(json.dumps(personas))     # deep copy
        self.cap = ctx_cap
        self.cur = -1
        root = QHBoxLayout(self)

        left = QVBoxLayout()
        self.lst = QListWidget()
        self.lst.currentRowChanged.connect(self.select)
        add = QPushButton("+ New persona")
        add.clicked.connect(self.add_persona)
        rem = QPushButton("Delete")
        rem.clicked.connect(self.del_persona)
        left.addWidget(self.lst, 1)
        left.addWidget(add)
        left.addWidget(rem)
        root.addLayout(left, 1)

        right = QVBoxLayout()
        form = QFormLayout()
        self.name = QLineEdit()
        self.prompt = QPlainTextEdit()
        self.prompt.setPlaceholderText("e.g. You are a patient C++ tutor. Explain step by step, "
                                       "give short examples, and ask me a practice question at the end.")
        self.own = QCheckBox("Keep this persona's memories separate (new facts are saved here, not in memory.md)")
        self.mem = QPlainTextEdit()
        self.mem.setPlaceholderText("One fact per line - the persona always knows these.")
        form.addRow("Name", self.name)
        form.addRow("Instructions", self.prompt)
        form.addRow("", self.own)
        form.addRow("Notes / memory", self.mem)
        right.addLayout(form)
        right.addWidget(QLabel("Pinned files (always included, trimmed to fit the context window):"))
        self.files = QListWidget()
        self.files.setMaximumHeight(90)
        right.addWidget(self.files)
        row = QHBoxLayout()
        addf = QPushButton("Pin file...")
        addf.clicked.connect(self.pin_file)
        remf = QPushButton("Unpin selected")
        remf.clicked.connect(self.unpin_file)
        row.addWidget(addf)
        row.addWidget(remf)
        row.addStretch(1)
        right.addLayout(row)
        box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        box.accepted.connect(self.accept)
        box.rejected.connect(self.reject)
        right.addWidget(box)
        root.addLayout(right, 3)
        self.reload_list()
        if self.personas:
            self.lst.setCurrentRow(0)

    def reload_list(self, row=None):
        self.lst.blockSignals(True)
        self.lst.clear()
        for p in self.personas:
            self.lst.addItem(p["name"])
        self.lst.blockSignals(False)
        if row is not None and 0 <= row < len(self.personas):
            self.lst.setCurrentRow(row)

    def commit(self):
        if 0 <= self.cur < len(self.personas):
            p = self.personas[self.cur]
            p["name"] = self.name.text().strip() or "Untitled"
            p["prompt"] = self.prompt.toPlainText().strip()
            p["own_memory"] = self.own.isChecked()
            p["memory"] = parse_memory_text(self.mem.toPlainText())
            item = self.lst.item(self.cur)
            if item:
                item.setText(p["name"])

    def select(self, row):
        self.commit()
        self.cur = row
        on = 0 <= row < len(self.personas)
        for w in (self.name, self.prompt, self.own, self.mem):
            w.setEnabled(on)
        if not on:
            return
        p = self.personas[row]
        self.name.setText(p["name"])
        self.prompt.setPlainText(p.get("prompt", ""))
        self.own.setChecked(p.get("own_memory", False))
        self.mem.setPlainText("\n".join(p.get("memory", [])))
        self.files.clear()
        for f in p.get("files", []):
            self.files.addItem(f"{f['name']}  ({len(f['text'])} chars)")

    def add_persona(self):
        self.commit()
        self.personas.append({"id": uuid.uuid4().hex, "name": "New persona", "prompt": "",
                              "own_memory": False, "memory": [], "files": []})
        self.cur = -1
        self.reload_list(len(self.personas) - 1)
        self.select(len(self.personas) - 1)

    def del_persona(self):
        r = self.lst.currentRow()
        if 0 <= r < len(self.personas):
            self.cur = -1
            del self.personas[r]
            self.reload_list()
            if self.personas:
                self.lst.setCurrentRow(min(r, len(self.personas) - 1))

    def pin_file(self):
        if not (0 <= self.cur < len(self.personas)):
            return
        paths, _ = QFileDialog.getOpenFileNames(self, "Pin files", "",
                                                "Documents (*.pdf *.docx *.txt *.md *.csv *.json *.py *.cpp *.h *.gd);;All files (*)")
        for path in paths:
            try:
                a = make_attachment(path, self.cap)
                if a["kind"] != "text":
                    raise ValueError(f"{a['name']}: only text files, PDFs and DOCX can be pinned")
                self.personas[self.cur].setdefault("files", []).append({"name": a["name"], "text": a["text"]})
            except ValueError as e:
                QMessageBox.warning(self, "Couldn't pin", str(e))
        self.select(self.cur)

    def unpin_file(self):
        r = self.files.currentRow()
        if 0 <= self.cur < len(self.personas) and r >= 0:
            del self.personas[self.cur]["files"][r]
            self.select(self.cur)

    def result_personas(self):
        self.commit()
        return self.personas


# ------------------------------------------------------------- input widget
class InputBox(QPlainTextEdit):
    submitted = Signal()
    files_dropped = Signal(list)
    image_pasted = Signal(QImage)

    def canInsertFromMimeData(self, source):
        return source.hasUrls() or source.hasImage() or super().canInsertFromMimeData(source)

    def insertFromMimeData(self, source):          # paste and drag & drop both land here
        if source.hasUrls():
            paths = [u.toLocalFile() for u in source.urls() if u.isLocalFile()]
            if paths:
                self.files_dropped.emit(paths)
                return
        if source.hasImage() and not source.hasText():
            data = source.imageData()
            if hasattr(data, "toImage"):
                data = data.toImage()
            if isinstance(data, QImage) and not data.isNull():
                self.image_pasted.emit(data)
                return
        super().insertFromMimeData(source)

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key_Return, Qt.Key_Enter) and not (e.modifiers() & Qt.ShiftModifier):
            self.submitted.emit()
            return
        super().keyPressEvent(e)


# --------------------------------------------------------------- main window
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Local Chat")
        self.resize(1250, 800)

        saved = load_json(SETTINGS_FILE, {})
        self.settings = {**DEFAULT_SETTINGS, **(saved if isinstance(saved, dict) else {})}
        self.personas = [p for p in _as_list(load_json(PERSONAS_FILE, []))
                         if isinstance(p, dict) and "id" in p and "name" in p]
        self.memories = load_memories()
        self.chats = [c for c in _as_list(load_json(CHATS_FILE, []))
                      if isinstance(c, dict) and {"id", "title", "messages"} <= c.keys()
                      and isinstance(c["messages"], list)]
        self.current_id = None

        self.worker = None
        self.old_workers = []
        self.bg_workers = []
        self.unload_workers = []
        self.search_worker = None
        self.search_token = 0
        self.run_worker = None
        self.run_chat = None
        self.web_job = None
        self.mic_worker = None
        self.speak_proc = None
        self.speaking_msg = None
        self.pending = []          # attachments waiting to be sent
        self.edit_idx = None       # index of the user message being edited
        self.caps_cache = {}
        self.active_id = None      # id of the generation we accept tokens from
        self.next_id = 0
        self.gen_chat = None
        self.base_est = 0
        self.expanded = set()      # (chat id, message index) thinking blocks that are open
        self.html_cache = {}
        self.dirty = False

        self._build_ui()
        self.apply_theme()
        self.refresh_models()
        self.refresh_personas()
        if not self.chats:
            self.new_chat()
        else:
            self.refresh_chat_list(self.chats[0]["id"])
            self.current_id = self.chats[0]["id"]
            self.sync_persona_box()
            self.render(force=True, to_bottom=True)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.render)
        self.timer.start(100)
        self.speak_timer = QTimer(self)
        self.speak_timer.timeout.connect(self.check_speaking)
        self._shortcuts()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        # sidebar
        side = QWidget()
        sl = QVBoxLayout(side)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search all chats...  (Ctrl+K)")
        self.search.setClearButtonEnabled(True)
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self.apply_search)
        self.search.textChanged.connect(lambda _t: self.search_timer.start(200))
        self.new_btn = QPushButton("+  New chat")
        self.new_btn.clicked.connect(self.new_chat)
        self.chat_list = QListWidget()
        self.chat_list.currentItemChanged.connect(self.on_select)
        self.chat_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.chat_list.customContextMenuRequested.connect(self.chat_menu)
        mem_btn = QPushButton("Memory")
        mem_btn.clicked.connect(self.open_memory)
        file_btn = QPushButton("Memory file")
        file_btn.setToolTip("Open memory.md in your default editor")
        file_btn.clicked.connect(self.open_memory_file)
        per_btn = QPushButton("Personas")
        per_btn.clicked.connect(self.open_personas)
        set_btn = QPushButton("Settings")
        set_btn.clicked.connect(self.open_settings)
        sl.addWidget(self.search)
        sl.addWidget(self.new_btn)
        sl.addWidget(self.chat_list, 1)
        sl.addWidget(mem_btn)
        sl.addWidget(file_btn)
        sl.addWidget(per_btn)
        sl.addWidget(set_btn)

        # main column
        main = QWidget()
        ml = QVBoxLayout(main)
        top = QHBoxLayout()
        top.addWidget(QLabel("Model"))
        self.model_box = QComboBox()
        self.model_box.setMinimumWidth(200)
        self.model_box.currentTextChanged.connect(self.on_model_changed)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh_models)
        top.addWidget(self.model_box)
        top.addWidget(refresh)
        top.addWidget(QLabel("Persona"))
        self.persona_box = QComboBox()
        self.persona_box.setMinimumWidth(140)
        self.persona_box.currentIndexChanged.connect(self.on_persona_changed)
        top.addWidget(self.persona_box)
        top.addStretch(1)
        self.meter = QProgressBar()
        self.meter.setFixedWidth(200)
        self.meter.setTextVisible(True)
        self.meter.setToolTip("How full the model's context window is.\n"
                              "When it gets near the limit, older messages are summarized automatically.")
        self.sum_btn = QPushButton("Summarize")
        self.sum_btn.setToolTip("Compress older messages into a short summary now")
        self.sum_btn.clicked.connect(lambda: self.start_summary(self.current_chat(), manual=True))
        self.status = QLabel("")
        top.addWidget(self.meter)
        top.addWidget(self.sum_btn)
        top.addWidget(self.status)
        ml.addLayout(top)

        self.view = QTextBrowser()
        self.view.setOpenLinks(False)
        self.view.setOpenExternalLinks(False)
        self.view.anchorClicked.connect(self.on_link)
        ml.addWidget(self.view, 1)

        # edit banner
        self.edit_bar = QWidget()
        el = QHBoxLayout(self.edit_bar)
        el.setContentsMargins(0, 0, 0, 0)
        self.edit_label = QLabel("Editing a message - Enter resends it as a new branch (the old version is kept).")
        cancel = QPushButton("Cancel edit")
        cancel.clicked.connect(self.cancel_edit)
        el.addWidget(self.edit_label, 1)
        el.addWidget(cancel)
        self.edit_bar.hide()
        ml.addWidget(self.edit_bar)

        self.attach_bar = QWidget()
        self.attach_layout = QHBoxLayout(self.attach_bar)
        self.attach_layout.setContentsMargins(0, 0, 0, 0)
        self.attach_bar.hide()
        ml.addWidget(self.attach_bar)

        self.input = InputBox()
        self.input.setPlaceholderText("Message...  (Enter to send, Shift+Enter for a new line)")
        self.input.setFixedHeight(100)
        self.input.submitted.connect(self.on_enter)
        self.input.files_dropped.connect(self.add_files)
        self.input.image_pasted.connect(self.add_pasted_image)
        self.send_btn = QPushButton("Send")
        self.send_btn.setMinimumWidth(110)
        self.send_btn.clicked.connect(self.on_send_clicked)
        self.attach_btn = QPushButton("Attach")
        self.attach_btn.setToolTip("Attach images, PDFs, documents or code files "
                                   "(you can also drag & drop, or paste an image)")
        self.attach_btn.clicked.connect(self.pick_files)
        self.mic_btn = QPushButton("Mic")
        self.mic_btn.setToolTip("Dictate a message (needs: pip install faster-whisper sounddevice)")
        self.mic_btn.clicked.connect(self.toggle_mic)
        self.web_chk = QCheckBox("Search the web")
        self.web_chk.setToolTip("Look the question up on DuckDuckGo first and give the results to the model\n"
                                "(Ctrl+Shift+W)")
        btns = QVBoxLayout()
        r1 = QHBoxLayout()
        r1.addWidget(self.attach_btn)
        r1.addWidget(self.mic_btn)
        btns.addLayout(r1)
        btns.addWidget(self.web_chk)
        btns.addWidget(self.send_btn)
        row = QHBoxLayout()
        row.addWidget(self.input, 1)
        row.addLayout(btns)
        ml.addLayout(row)

        self.regen_btn = QPushButton("Regenerate")
        self.regen_btn.clicked.connect(self.regenerate)
        copy_btn = QPushButton("Copy last reply")
        copy_btn.clicked.connect(self.copy_last)
        savebtn = QPushButton("Save last reply as...")
        savebtn.setToolTip("Save as .md, .txt, .html or .docx")
        savebtn.clicked.connect(lambda: self.save_reply_as(None))
        export_btn = QPushButton("Export chat")
        export_btn.clicked.connect(lambda: self.export_chat())
        help_btn = QPushButton("Shortcuts")
        help_btn.clicked.connect(self.show_shortcuts)
        tools = QHBoxLayout()
        for b in (self.regen_btn, copy_btn, savebtn, export_btn):
            tools.addWidget(b)
        tools.addStretch(1)
        tools.addWidget(help_btn)
        ml.addLayout(tools)

        split = QSplitter()
        split.addWidget(side)
        split.addWidget(main)
        split.setStretchFactor(1, 1)
        split.setSizes([270, 980])
        self.setCentralWidget(split)
        self.set_send_mode("send")
        self.view.viewport().setAcceptDrops(False)
        self.setAcceptDrops(True)

    SHORTCUTS = [
        ("Ctrl+N", "New chat"), ("Ctrl+K / Ctrl+F", "Search all chats"),
        ("Ctrl+L", "Focus the message box"), ("Esc", "Stop generating / cancel edit / stop speaking"),
        ("Ctrl+R", "Regenerate the last reply"), ("Ctrl+Shift+C", "Copy the last reply"),
        ("Ctrl+Shift+S", "Save the last reply as a file"), ("Ctrl+E", "Export this chat"),
        ("Ctrl+Shift+W", "Toggle web search"), ("Ctrl+Shift+P", "Personas"),
        ("Ctrl+,", "Settings"), ("Ctrl+T", "Switch light / dark theme"),
        ("Ctrl+=  /  Ctrl+-", "Bigger / smaller chat text"), ("Ctrl+/", "This list"),
    ]

    def _shortcuts(self):
        def sc(keys, fn):
            s = QShortcut(QKeySequence(keys), self)
            s.activated.connect(fn)
        sc("Ctrl+N", self.new_chat)
        sc("Ctrl+K", self.focus_search)
        sc("Ctrl+F", self.focus_search)
        sc("Ctrl+L", lambda: self.input.setFocus())
        sc("Esc", self.on_escape)
        sc("Ctrl+R", self.regenerate)
        sc("Ctrl+Shift+C", self.copy_last)
        sc("Ctrl+Shift+S", lambda: self.save_reply_as(None))
        sc("Ctrl+E", lambda: self.export_chat())
        sc("Ctrl+Shift+W", lambda: self.web_chk.toggle())
        sc("Ctrl+Shift+P", self.open_personas)
        sc("Ctrl+,", self.open_settings)
        sc("Ctrl+T", self.toggle_theme)
        sc("Ctrl+=", lambda: self.zoom(1))
        sc("Ctrl++", lambda: self.zoom(1))
        sc("Ctrl+-", lambda: self.zoom(-1))
        sc("Ctrl+/", self.show_shortcuts)

    def show_shortcuts(self):
        QMessageBox.information(self, "Keyboard shortcuts",
                                "\n".join(f"{k:<20}{v}" for k, v in self.SHORTCUTS))

    def focus_search(self):
        self.search.setFocus()
        self.search.selectAll()

    def on_escape(self):
        if self.worker or self.search_worker:
            self.stop_generation()
        elif self.edit_idx is not None:
            self.cancel_edit()
        elif self.speak_proc:
            self.stop_speaking()
        elif self.search.text():
            self.search.clear()

    def apply_theme(self):
        t = THEMES.get(self.settings["theme"], THEMES["dark"])
        QApplication.instance().setStyleSheet(make_style(t, self.settings["font_size"]))
        self.html_cache.clear()
        self.dirty = True

    def toggle_theme(self):
        self.settings["theme"] = "light" if self.settings["theme"] == "dark" else "dark"
        save_json(SETTINGS_FILE, self.settings)
        self.apply_theme()
        self.render(force=True)

    def zoom(self, d):
        self.settings["font_size"] = max(10, min(28, self.settings["font_size"] + d))
        save_json(SETTINGS_FILE, self.settings)
        self.apply_theme()
        self.render(force=True)

    def set_send_mode(self, mode):
        self.send_btn.setText("Stop" if mode == "stop" else "Send")
        self.send_btn.setProperty("mode", mode)
        self.send_btn.style().unpolish(self.send_btn)
        self.send_btn.style().polish(self.send_btn)

    # -------------------------------------------------------------- models
    def refresh_models(self):
        names = []
        try:
            r = requests.get(f"{OLLAMA}/api/tags", timeout=3)
            names = [m["name"] for m in r.json().get("models", [])]
            self.status.setText("")
        except Exception:
            self.status.setText("Can't reach Ollama - is it running?")
        if not names:
            names = [self.settings["model"]]
        self.model_box.blockSignals(True)
        self.model_box.clear()
        self.model_box.addItems(names)
        if self.settings["model"] in names:
            self.model_box.setCurrentText(self.settings["model"])
        else:
            self.settings["model"] = names[0]
        self.model_box.blockSignals(False)

    def on_model_changed(self, name):
        if not name:
            return
        prev = self.settings["model"]
        self.settings["model"] = name
        save_json(SETTINGS_FILE, self.settings)
        if prev and prev != name and self.settings["unload_on_switch"]:
            self.unload_model(prev)

    def unload_model(self, model):
        busy = self.old_workers + self.bg_workers      # requests that may still use it
        w = UnloadWorker(model, [t for t in busy if t.isRunning()])
        w.done.connect(self.notify)
        self.unload_workers = [x for x in self.unload_workers if x.isRunning()]
        self.unload_workers.append(w)
        w.start()

    def get_caps(self, model):
        """Ollama's capability list for a model (e.g. ['completion','vision','thinking']), or None."""
        if model not in self.caps_cache:
            try:
                r = requests.post(f"{OLLAMA}/api/show", json={"model": model}, timeout=5).json()
                self.caps_cache[model] = r.get("capabilities")
            except Exception:
                return None
        return self.caps_cache[model]

    def supports_vision(self, model):
        caps = self.get_caps(model)
        return None if caps is None else ("vision" in caps)

    # ------------------------------------------------------------ personas
    def persona_of(self, chat):
        pid = (chat or {}).get("persona")
        return next((p for p in self.personas if p["id"] == pid), None) if pid else None

    def save_personas(self):
        save_json(PERSONAS_FILE, self.personas)

    def refresh_personas(self):
        self.persona_box.blockSignals(True)
        self.persona_box.clear()
        self.persona_box.addItem("None", "")
        for p in self.personas:
            self.persona_box.addItem(p["name"], p["id"])
        self.persona_box.blockSignals(False)
        self.sync_persona_box()

    def sync_persona_box(self):
        chat = self.current_chat()
        pid = (chat or {}).get("persona", "") if chat else ""
        i = self.persona_box.findData(pid)
        self.persona_box.blockSignals(True)
        self.persona_box.setCurrentIndex(i if i >= 0 else 0)
        self.persona_box.blockSignals(False)

    def on_persona_changed(self, _i):
        chat = self.current_chat()
        pid = self.persona_box.currentData() or ""
        self.settings["last_persona"] = pid
        save_json(SETTINGS_FILE, self.settings)
        if chat is not None:
            chat["persona"] = pid
            self.save_chats()
            self.refresh_meter()
            p = self.persona_of(chat)
            self.notify(f"Persona: {p['name']}" if p else "Persona: none")

    def open_personas(self):
        dlg = PersonaDialog(self.personas, self.settings["num_ctx"] * 3, self)
        if dlg.exec():
            self.personas = dlg.result_personas()
            self.save_personas()
            self.refresh_personas()
            self.refresh_meter()

    # --------------------------------------------------------------- chats
    def current_chat(self):
        for c in self.chats:
            if c["id"] == self.current_id:
                return c
        return None

    def chat_match(self, chat, words):
        """(matches, snippet) for the sidebar search: every word must occur somewhere in the chat."""
        blob_parts = [chat["title"].lower()]
        blob_parts += [strip_tags(m["content"]).lower() for m in chat["messages"] if m.get("content")]
        blob = "\n".join(blob_parts)
        if not all(w in blob for w in words):
            return False, ""
        if all(w in chat["title"].lower() for w in words):
            return True, ""
        for m in chat["messages"]:
            c = strip_tags(m.get("content", ""))
            low = c.lower()
            pos = low.find(words[0])
            if pos >= 0:
                s = " ".join(c[max(0, pos - 30): pos + 70].split())
                return True, "..." + s + "..."
        return True, ""

    def refresh_chat_list(self, select_id=None):
        words = self.search.text().strip().lower().split() if hasattr(self, "search") else []
        self.chat_list.blockSignals(True)
        self.chat_list.clear()
        for c in sorted(self.chats, key=lambda c: not c.get("pinned")):
            snippet = ""
            if words:
                ok, snippet = self.chat_match(c, words)
                if not ok:
                    continue
            label = ("\u2605 " if c.get("pinned") else "") + c["title"]
            it = QListWidgetItem(label + (f"\n{snippet}" if snippet else ""))
            it.setData(Qt.UserRole, c["id"])
            self.chat_list.addItem(it)
            if c["id"] == select_id:
                self.chat_list.setCurrentItem(it)
        self.chat_list.blockSignals(False)

    def apply_search(self):
        self.refresh_chat_list(self.current_id)
        if self.search.text().strip():
            self.highlight_search()

    def highlight_search(self):
        words = self.search.text().strip().split()
        if not words:
            return
        self.view.moveCursor(QTextCursor.Start)
        if not self.view.find(words[0]):
            self.view.moveCursor(QTextCursor.Start)

    def new_chat(self):
        cur = self.current_chat()
        if cur and not cur["messages"]:
            self.input.setFocus()
            return
        self.cancel_edit()
        pid = self.settings.get("last_persona", "")
        chat = {"id": uuid.uuid4().hex, "title": "New chat",
                "created": time.time(), "updated": time.time(), "messages": [],
                "persona": pid if any(p["id"] == pid for p in self.personas) else "",
                "forks": {}, "rev": 0}
        self.chats.insert(0, chat)
        self.current_id = chat["id"]
        self.search.blockSignals(True)
        self.search.clear()
        self.search.blockSignals(False)
        self.refresh_chat_list(chat["id"])
        self.sync_persona_box()
        self.render(force=True, to_bottom=True)
        self.input.setFocus()
        self.save_chats()

    def on_select(self, cur, _prev):
        if cur:
            cid = cur.data(Qt.UserRole)
            if cid != self.current_id:
                self.cancel_edit()
            self.current_id = cid
            self.sync_persona_box()
            self.render(force=True, to_bottom=True)
            self.highlight_search()

    def chat_menu(self, pos):
        item = self.chat_list.itemAt(pos)
        if not item:
            return
        cid = item.data(Qt.UserRole)
        chat = next((c for c in self.chats if c["id"] == cid), None)
        if not chat:
            return
        menu = QMenu(self)
        rename = menu.addAction("Rename")
        pin = menu.addAction("Unpin" if chat.get("pinned") else "Pin to top")
        export = menu.addAction("Export...")
        delete = menu.addAction("Delete")
        act = menu.exec(self.chat_list.mapToGlobal(pos))
        if act == rename:
            text, ok = QInputDialog.getText(self, "Rename chat", "Title:", text=chat["title"])
            if ok and text.strip():
                chat["title"] = text.strip()
                chat["auto_title"] = False
                self.refresh_chat_list(self.current_id)
                self.save_chats()
        elif act == pin:
            chat["pinned"] = not chat.get("pinned")
            self.refresh_chat_list(self.current_id)
            self.save_chats()
        elif act == export:
            self.export_chat(chat)
        elif act == delete:
            if self.worker and self.gen_chat is chat:
                self.stop_generation()
            self.cancel_edit()
            self.delete_attachment_files(chat)
            self.chats.remove(chat)
            if not self.chats:
                self.current_id = None
                self.new_chat()
            else:
                if self.current_id == cid:
                    self.current_id = self.chats[0]["id"]
                self.refresh_chat_list(self.current_id)
                self.sync_persona_box()
                self.render(force=True, to_bottom=True)
            self.save_chats()

    def save_chats(self):
        save_json(CHATS_FILE, self.chats)

    @staticmethod
    def iter_messages(chat):
        """Every message of a chat, including those parked in older branches."""
        for m in chat["messages"]:
            yield m
        for fk in chat.get("forks", {}).values():
            for snap in fk.get("variants", []):
                if snap:
                    yield from snap["msgs"]
                    for fk2 in snap.get("forks", {}).values():
                        for s2 in fk2.get("variants", []):
                            if s2:
                                yield from s2["msgs"]

    # ----------------------------------------------------------- rendering
    def msg_parts(self, m):
        """(thinking, answer, still_thinking) for an assistant message."""
        th, ans, open_ = split_think(m.get("content", ""))
        thinking = "\n\n".join(x for x in (m.get("thinking", "").strip(), th) if x)
        return thinking, strip_tags(ans), open_

    def render(self, force=False, to_bottom=False):
        if not (force or self.dirty):
            return
        self.dirty = False
        chat = self.current_chat()
        t = THEMES.get(self.settings["theme"], THEMES["dark"])
        parts = []
        if chat:
            msgs = chat["messages"]
            n = len(msgs)
            streaming = self.gen_chat is chat and self.worker is not None
            forks = chat.get("forks", {})
            for i, m in enumerate(msgs):
                fk = forks.get(str(i)) if m["role"] == "user" else None
                fk_sig = (fk["cur"], len(fk["variants"])) if fk and len(fk["variants"]) > 1 else None
                live = streaming and i == n - 1
                sig = (m["content"], m.get("thinking", ""), m["role"], (chat["id"], i) in self.expanded,
                       i == n - 1, live, fk_sig, self.settings["theme"], self.settings["font_size"],
                       self.settings["allow_run"], self.speaking_msg == i, len(m.get("sources", [])),
                       len(msgs[i - 1].get("sources", [])) if i else 0,
                       len(m.get("attachments", [])))
                cached = self.html_cache.get((chat["id"], i))
                if cached and cached[0] == sig and not live:
                    parts.append(cached[1])
                    continue
                h = self.render_message(chat, i, m, t, fk_sig, live)
                self.html_cache[(chat["id"], i)] = (sig, h)
                parts.append(h)
        if parts:
            body = f'<hr style="border-color:{t["border"]}">'.join(parts)
        else:
            body = f'<p style="color:{t["muted"]}"><i>Start a conversation below. Type /help for commands.</i></p>'
        sb = self.view.verticalScrollBar()
        at_bottom = to_bottom or sb.value() >= sb.maximum() - 20
        old = sb.value()
        self.view.setHtml(f'<body style="color:{t["text"]}">{body}</body>')
        sb.setValue(sb.maximum() if at_bottom else old)
        self.refresh_meter()

    def render_message(self, chat, i, m, t, fk_sig, live):
        link = f'color:{t["link"]}; text-decoration:none'
        small = "font-size:12px"
        role = m["role"]
        if role == "user":
            nav = ""
            if fk_sig:
                cur, total = fk_sig
                nav = (f' &nbsp;<a href="lc:fk:{i}:-1" style="{link}">&#9664;</a> '
                       f'<span style="color:{t["muted"]}">{cur + 1}/{total}</span> '
                       f'<a href="lc:fk:{i}:1" style="{link}">&#9654;</a>')
            head = (f'<b>You</b> &nbsp; <span style="{small}"><a href="lc:edit:{i}" style="{link}">Edit</a>'
                    f'{nav}</span>')
            body = html.escape(m["content"]).replace("\n", "<br>").replace("  ", "&nbsp; ")
            extra = ""
            for a in m.get("attachments", []):
                if a["kind"] == "image":
                    url = QUrl.fromLocalFile(a["thumb"]).toString()
                    extra += f'<br><img src="{url}">'
                else:
                    note = " (shortened)" if a.get("truncated") else ""
                    extra += f'<br><i style="color:{t["muted"]}">Attached: {html.escape(a["name"])}{note}</i>'
            if m.get("sources"):
                extra += f'<br><i style="color:{t["muted"]}">Web search used</i>'
            return (f'<table width="100%" cellspacing="0" cellpadding="8"><tr><td bgcolor="{t["user_bg"]}">'
                    f'{head}<br>{body}{extra}</td></tr></table>')
        if role == "output":
            label = "Output" if m.get("code", 0) == 0 else f"Output (exit code {m.get('code')})"
            feed = ""
            if i == len(chat["messages"]) - 1:
                feed = (f' &nbsp; <span style="{small}"><a href="lc:feed:{i}" style="{link}">'
                        f'Ask the model about this</a></span>')
            return (f'<p><b>{label}</b>{feed}</p>' +
                    code_block_html(m["content"], "output", t))
        # assistant
        thinking, ans, _open = self.msg_parts(m)
        name = html.escape(m.get("model", "Assistant"))
        speak_label = "Stop" if self.speaking_msg == i else "Speak"
        acts = [f'<a href="lc:cpy:{i}" style="{link}">Copy</a>',
                f'<a href="lc:speak:{i}" style="{link}">{speak_label}</a>',
                f'<a href="lc:saveas:{i}" style="{link}">Save as...</a>']
        if i == len(chat["messages"]) - 1 and not live:
            acts.append(f'<a href="lc:regen:{i}" style="{link}">Regenerate</a>')
        head = f'<b>{name}</b> &nbsp; <span style="{small}">' + " &middot; ".join(acts) + "</span>"
        out = [f"<p style='margin-bottom:2px'>{head}</p>"]
        if thinking:
            live_think = live and not ans.strip()
            exp = live_think or (chat["id"], i) in self.expanded
            words = len(thinking.split())
            label = "Thinking..." if live_think else f"Thought process ({words} words)"
            out.append(f'<p style="margin:2px"><a href="lc:think:{i}" style="color:{t["muted"]}; '
                       f'text-decoration:none">{"&#9662;" if exp else "&#9656;"} {label}</a></p>')
            if exp:
                tx = html.escape(thinking).replace("\n", "<br>")
                out.append(f'<table width="100%" cellpadding="8" cellspacing="0"><tr><td bgcolor="{t["quote"]}">'
                           f'<i style="color:{t["muted"]}">{tx}</i></td></tr></table>')

        def block_links(bi, lang, code, closed):
            ls = [("Copy", f"lc:copy:{i}:{bi}"), ("Save", f"lc:save:{i}:{bi}")]
            if self.settings["allow_run"] and lang in ("python", "py", "python3"):
                ls.append(("Run", f"lc:run:{i}:{bi}"))
            return ls

        if ans.strip():
            h, _ = markdown_html(ans, t, block_links)
            out.append(h)
        elif not thinking:
            out.append(f'<p style="color:{t["muted"]}">...</p>')
        srcs = m.get("sources")
        if not srcs and i > 0 and chat["messages"][i - 1]["role"] == "user":
            srcs = chat["messages"][i - 1].get("sources")      # sources live on the question
        if srcs:
            lines = "<br>".join(
                f'[{k + 1}] <a href="{html.escape(s["url"])}" style="{link}">{html.escape(s["title"][:80])}</a>'
                for k, s in enumerate(srcs))
            out.append(f'<p style="{small}; color:{t["muted"]}">Sources<br>{lines}</p>')
        return "".join(out)

    def on_link(self, url):
        s = url.toString()
        if s.startswith("lc:"):
            self.do_action(s[3:].split(":"))
        elif s.startswith(("http://", "https://")):
            QDesktopServices.openUrl(url)

    def get_block(self, i, b):
        chat = self.current_chat()
        if not chat or not (0 <= i < len(chat["messages"])):
            return None
        blocks = find_code_blocks(self.msg_parts(chat["messages"][i])[1])
        return blocks[b] if 0 <= b < len(blocks) else None

    def do_action(self, a):
        chat = self.current_chat()
        if not chat:
            return
        kind = a[0]
        try:
            i = int(a[1])
        except (IndexError, ValueError):
            return
        if kind == "think":
            key = (chat["id"], i)
            self.expanded.symmetric_difference_update({key})
            self.dirty = True
        elif kind == "copy":
            blk = self.get_block(i, int(a[2]))
            if blk:
                QGuiApplication.clipboard().setText(blk[1])
                self.notify("Code copied to the clipboard.")
        elif kind == "save":
            blk = self.get_block(i, int(a[2]))
            if blk:
                self.save_code(blk[0], blk[1])
        elif kind == "run":
            blk = self.get_block(i, int(a[2]))
            if blk:
                self.run_code(chat, blk[1])
        elif kind == "cpy":
            if 0 <= i < len(chat["messages"]):
                QGuiApplication.clipboard().setText(self.msg_parts(chat["messages"][i])[1])
                self.notify("Reply copied.")
        elif kind == "speak":
            if self.speaking_msg == i:
                self.stop_speaking()
            elif 0 <= i < len(chat["messages"]):
                self.speak(self.msg_parts(chat["messages"][i])[1], i)
        elif kind == "saveas":
            self.save_reply_as(i)
        elif kind == "regen":
            self.regenerate()
        elif kind == "edit":
            self.begin_edit(i)
        elif kind == "fk":
            self.switch_variant(chat, i, int(a[2]))
        elif kind == "feed":
            if not self.worker and not self.search_worker:
                self.generate(chat)

    # ---------------------------------------------------------- generation
    def on_enter(self):
        if self.worker or self.search_worker:
            self.status.setText("Still working - press Stop first.")
            return
        self.send()

    def on_send_clicked(self):
        if self.worker or self.search_worker:
            self.stop_generation()
        else:
            self.send()

    def send(self):
        text = self.input.toPlainText().strip()
        atts = list(self.pending)
        if not text and not atts:
            return
        force_web = False
        if text.lower().startswith("/web ") and not atts:
            text, force_web = text[5:].strip(), True
            if not text:
                return
        elif text.startswith("/") and not atts and self.handle_command(text):
            self.input.clear()
            return
        chat = self.current_chat()
        if not chat:
            return
        if any(a["kind"] == "image" for a in atts):
            model = self.model_box.currentText() or self.settings["model"]
            if self.supports_vision(model) is False:
                QMessageBox.warning(
                    self, "This model can't see images",
                    f"{model} doesn't support images.\nSwitch to a vision model such as "
                    "gemma3:4b (top bar), or remove the image(s).")
                return
        self.input.clear()
        text = text or "Please look at the attached file(s)."
        msg = {"role": "user", "content": text}
        if atts:
            msg["attachments"] = [{k: v for k, v in a.items() if k != "shared"} for a in atts]
            self.pending = []
            self.refresh_chips()
        if self.edit_idx is not None:
            self.commit_edit(chat, self.edit_idx, msg)
        else:
            chat["messages"].append(msg)
        if chat["title"] == "New chat":
            chat["title"] = text[:40] + ("..." if len(text) > 40 else "")
            chat["auto_title"] = True
            self.refresh_chat_list(self.current_id)
        self.save_chats()
        if self.web_chk.isChecked() or force_web:
            self.start_web(chat, msg, text)
        else:
            self.generate(chat)

    # ------------------------------------------------------- edit / branches
    def snapshot(self, chat, i):
        return {"msgs": chat["messages"][i:],
                "forks": {k: v for k, v in chat.get("forks", {}).items() if int(k) > i}}

    def reset_summary_if_needed(self, chat, i):
        if chat.get("summary") and chat.get("summary_upto", 0) > i:
            chat.pop("summary", None)
            chat.pop("summary_upto", None)
        chat.pop("usage", None)
        chat["rev"] = chat.get("rev", 0) + 1

    def begin_edit(self, i):
        chat = self.current_chat()
        if not chat or self.worker or self.search_worker:
            self.status.setText("Wait for the reply to finish (or press Stop) before editing.")
            return
        if not (0 <= i < len(chat["messages"])) or chat["messages"][i]["role"] != "user":
            return
        self.clear_pending(delete=True)
        m = chat["messages"][i]
        self.edit_idx = i
        self.pending = [{**a, "shared": True} for a in m.get("attachments", [])]
        self.refresh_chips()
        self.input.setPlainText(m["content"])
        self.edit_bar.show()
        self.input.setFocus()
        self.input.moveCursor(QTextCursor.End)

    def cancel_edit(self):
        if self.edit_idx is None:
            return
        self.edit_idx = None
        self.edit_bar.hide()
        self.clear_pending(delete=True)
        self.input.clear()

    def commit_edit(self, chat, i, msg):
        """Replace message i by `msg`, parking the old version (and everything after it) as a branch."""
        forks = chat.setdefault("forks", {})
        key = str(i)
        fk = forks.get(key)
        if fk is None:
            fk = {"variants": [None], "cur": 0}
        fk["variants"][fk["cur"]] = self.snapshot(chat, i)
        chat["forks"] = {k: v for k, v in forks.items() if int(k) < i}
        chat["forks"][key] = fk
        del chat["messages"][i:]
        chat["messages"].append(msg)
        fk["variants"].append(None)
        fk["cur"] = len(fk["variants"]) - 1
        self.reset_summary_if_needed(chat, i)
        self.edit_idx = None
        self.edit_bar.hide()
        self.html_cache.clear()

    def switch_variant(self, chat, i, delta):
        if self.worker or self.search_worker:
            self.status.setText("Wait for the reply to finish before switching versions.")
            return
        fk = chat.get("forks", {}).get(str(i))
        if not fk:
            return
        new = fk["cur"] + delta
        if not (0 <= new < len(fk["variants"])) or fk["variants"][new] is None:
            return
        fk["variants"][fk["cur"]] = self.snapshot(chat, i)
        snap = fk["variants"][new]
        fk["variants"][new] = None
        chat["messages"] = chat["messages"][:i] + snap["msgs"]
        keep = {k: v for k, v in chat["forks"].items() if int(k) <= i}
        keep.update(snap.get("forks", {}))
        chat["forks"] = keep
        fk["cur"] = new
        self.reset_summary_if_needed(chat, i)
        self.html_cache.clear()
        self.save_chats()
        self.render(force=True)

    # ------------------------------------------------------------ web search
    def start_web(self, chat, msg, query):
        self.search_token += 1
        token = self.search_token
        budget = int(self.settings["num_ctx"] * 3.5 * 0.4)
        w = SearchWorker(query[:200], self.settings["web_pages"], budget, token)
        self.web_job = (token, chat, msg)
        w.result.connect(self.on_web_result)
        self.bg_workers = [x for x in self.bg_workers if x.isRunning()]
        self.bg_workers.append(w)
        self.search_worker = w
        self.set_busy(True)
        self.status.setText("Searching the web...")
        self.render(force=True, to_bottom=True)
        w.start()

    def on_web_result(self, res):
        job = self.web_job
        if not job or res.get("token") != job[0] or job[0] != self.search_token:
            return                                  # cancelled
        _token, chat, msg = job
        self.web_job = None
        self.search_worker = None
        if res.get("error"):
            self.notify(res["error"] + " Answering without it.")
        else:
            msg["web_ctx"] = res["context"]
            msg["sources"] = [{"title": r["title"], "url": r["url"]} for r in res["results"]]
            msg["web_query"] = res["query"]
        self.html_cache.clear()
        if chat["messages"] and chat["messages"][-1] is msg:
            self.generate(chat)
        else:
            self.set_busy(False)
            self.status.setText("")

    # ---------------------------------------------------------- attachments
    def pick_files(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Attach files", "",
            "All files (*);;Images (*.png *.jpg *.jpeg *.gif *.bmp *.webp);;"
            "Documents (*.pdf *.docx *.txt *.md *.csv *.json)")
        if paths:
            self.add_files(paths)

    def add_files(self, paths):
        cap = self.settings["num_ctx"] * 3
        errors, cut = [], []
        for path in paths:
            if len(self.pending) >= MAX_PENDING:
                errors.append(f"Max {MAX_PENDING} attachments per message.")
                break
            try:
                a = make_attachment(path, cap)
            except (ValueError, OSError) as e:
                errors.append(str(e))
                continue
            self.pending.append(a)
            if a.get("truncated"):
                cut.append(a["name"])
        self.refresh_chips()
        if cut:
            self.notify("Shortened to fit the context window: " + ", ".join(cut)
                        + ". Raise 'Context size' in Settings for longer files.")
        if errors:
            QMessageBox.warning(self, "Couldn't attach", "\n".join(errors))
        self.input.setFocus()

    def add_pasted_image(self, img):
        if len(self.pending) >= MAX_PENDING:
            return
        try:
            self.pending.append(store_image(img, "pasted image"))
        except ValueError as e:
            QMessageBox.warning(self, "Couldn't attach", str(e))
        self.refresh_chips()

    def remove_pending(self, i):
        if 0 <= i < len(self.pending):
            a = self.pending.pop(i)
            if not a.get("shared"):
                self.delete_attachment_files({"messages": [{"attachments": [a]}]})
            self.refresh_chips()

    def clear_pending(self, delete=False):
        if delete:
            self.delete_attachment_files(
                {"messages": [{"attachments": [a for a in self.pending if not a.get("shared")]}]})
        self.pending = []
        self.refresh_chips()

    def refresh_chips(self):
        while self.attach_layout.count():
            item = self.attach_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for i, a in enumerate(self.pending):
            name = a["name"] if len(a["name"]) <= 28 else a["name"][:25] + "..."
            b = QPushButton(f"{name}   x")
            b.setToolTip("Click to remove")
            b.clicked.connect(lambda _=False, i=i: self.remove_pending(i))
            self.attach_layout.addWidget(b)
        self.attach_layout.addStretch(1)
        self.attach_bar.setVisible(bool(self.pending))

    def delete_attachment_files(self, chat):
        for m in (self.iter_messages(chat) if "id" in chat else chat["messages"]):
            for a in m.get("attachments", []):
                for key in ("path", "thumb"):
                    if a.get(key):
                        try:
                            Path(a[key]).unlink(missing_ok=True)
                        except OSError:
                            pass

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.add_files(paths)

    # ------------------------------------------------- building the prompt
    def recall(self, chat, query, k=3):
        """Keyword search over older messages (other chats + this chat beyond the window)."""
        q = tokens(query)
        if not q:
            return []
        need = 1 if len(q) <= 3 else 2
        window = {id(m) for m in chat["messages"][-self.settings["max_history"]:]}
        hits = []
        for c in self.chats:
            for m in c["messages"]:
                if (c is chat and id(m) in window) or not m.get("content") or m["role"] == "output":
                    continue
                score = len(q & tokens(m["content"]))
                if score >= need:
                    hits.append((score, c.get("updated", 0), c["title"], m))
        hits.sort(key=lambda h: (h[0], h[1]), reverse=True)
        out = []
        for _score, _t, title, m in hits[:k]:
            who = "User said" if m["role"] == "user" else "Assistant said"
            text = " ".join(self.msg_parts(m)[1].split())[:300] if m["role"] == "assistant" \
                else " ".join(m["content"].split())[:300]
            out.append(f'- [{title}] {who}: {text}')
        return out

    def memory_owner(self, chat):
        p = self.persona_of(chat)
        return p if p and p.get("own_memory") else None

    def mem_load(self, chat):
        p = self.memory_owner(chat)
        return list(p.get("memory", [])) if p else load_memories()

    def mem_save(self, chat, items):
        p = self.memory_owner(chat)
        if p:
            p["memory"] = list(items)
            self.save_personas()
        else:
            save_memories(items)

    def build_messages(self, chat, light=False):
        s = self.settings
        persona = self.persona_of(chat)
        own = bool(persona and persona.get("own_memory"))
        mems = self.mem_load(chat)
        self.memories = mems
        system = (persona.get("prompt", "").strip() if persona and persona.get("prompt", "").strip()
                  else s["system_prompt"].strip())
        if persona and persona.get("files"):
            budget = int(s["num_ctx"] * 3.5 * 0.25)
            per = max(400, budget // len(persona["files"]))
            for f in persona["files"]:
                system += f"\n\n--- Pinned file: {f['name']} ---\n{neutralize(f['text'][:per])}\n--- end of {f['name']} ---"
        if persona and not own and persona.get("memory"):
            system += "\n\nNotes for this persona:\n" + "\n".join(f"- {m}" for m in persona["memory"])
        if s["use_memory"]:
            shown, size = [], 0
            for m in reversed(mems):             # newest first, capped to protect context
                size += len(m) + 3
                if size > 3000:
                    break
                shown.append(m)
            listing = "\n".join(f"- {m}" for m in reversed(shown)) or "(empty)"
            label = "Persona memory" if own else "Memory file contents"
            system += MEMORY_INSTRUCTIONS + f"\n\n{label}:\n" + listing
        msgs = chat["messages"]
        upto = chat.get("summary_upto", 0)
        if chat.get("summary") and 0 < upto < len(msgs):
            system += "\n\nSummary of the earlier part of this conversation:\n" + chat["summary"]
        else:
            upto = 0
        if s["recall_past"] and not light:
            last_user = next((m["content"] for m in reversed(msgs) if m["role"] == "user"), "")
            excerpts = self.recall(chat, last_user)
            if excerpts:
                system += ("\n\nPossibly relevant excerpts from earlier conversations "
                           "(use only if helpful):\n" + "\n".join(excerpts))
        last_user_i = next((i for i in range(len(msgs) - 1, -1, -1) if msgs[i]["role"] == "user"), -1)
        if last_user_i >= 0 and msgs[last_user_i].get("web_ctx"):
            system += "\n\n" + WEB_INSTRUCTIONS
        start = max(upto, len(msgs) - s["max_history"])
        history = msgs[start:]
        out = [{"role": "system", "content": system}] if system else []
        out += self.history_for_model(history, last_user_i - start)
        return out

    def history_for_model(self, history, web_idx=-1):
        """Stored messages -> API messages, inlining attached file text.
        Newest attachments get the character budget first; only the most recent
        message with images keeps its pixels (vision is slow on CPU)."""
        budget = self.settings["num_ctx"] * 3
        last_img = max((i for i, m in enumerate(history)
                        if any(a["kind"] == "image" for a in m.get("attachments", []))),
                       default=-1)
        msgs = [None] * len(history)
        for i in range(len(history) - 1, -1, -1):
            m = history[i]
            content, images = m["content"], []
            role = m["role"]
            if role == "assistant":
                content = self.msg_parts(m)[1]
            elif role == "output":
                role = "user"
                content = f"[Output of the code I ran]\n```\n{neutralize(content)}\n```"
            for a in m.get("attachments", []):
                if a["kind"] == "image":
                    if i == last_img and Path(a["path"]).exists():
                        images.append(base64.b64encode(Path(a["path"]).read_bytes()).decode())
                    else:
                        content += f"\n\n[Image attached earlier: {a['name']}]"
                elif budget > 300:
                    tx = neutralize(a["text"][:budget])
                    budget -= len(tx)
                    note = " (shortened to fit)" if (a.get("truncated") or len(tx) < len(a["text"])) else ""
                    content += f"\n\n--- Attached file: {a['name']}{note} ---\n```\n{tx}\n```"
                else:
                    content += f"\n\n[Attached file {a['name']} left out: no room left in the context window]"
            if i == web_idx and m.get("web_ctx"):
                content += (f"\n\n--- Web search results for \"{m.get('web_query', '')}\" ---\n"
                            f"{neutralize(m['web_ctx'])}\n--- end of web results ---")
            msg = {"role": role, "content": content}
            if images:
                msg["images"] = images
            msgs[i] = msg
        return msgs

    def count_tokens(self, msgs):
        total = 0
        for m in msgs:
            total += est_tokens(m["content"]) + 4 + 300 * len(m.get("images", []))
        return total

    def context_estimate(self, chat):
        return self.count_tokens(self.build_messages(chat, light=True))

    def refresh_meter(self):
        chat = self.current_chat()
        if not chat:
            return
        ctx = max(1, self.settings["num_ctx"])
        if self.gen_chat is chat and self.worker and chat["messages"]:
            m = chat["messages"][-1]
            used = self.base_est + est_tokens(m.get("content", "") + m.get("thinking", ""))
        elif chat.get("usage") and chat.get("usage_len") == len(chat["messages"]):
            used = chat["usage"]
        else:
            used = self.context_estimate(chat)
        pct = min(100, int(used * 100 / ctx))
        self.meter.setValue(pct)
        self.meter.setFormat(f"Context  {used:,} / {ctx:,}")
        warn = 2 if pct >= 92 else 1 if pct >= 75 else 0
        if self.meter.property("warn") != warn:
            self.meter.setProperty("warn", warn)
            self.meter.style().unpolish(self.meter)
            self.meter.style().polish(self.meter)

    def generate(self, chat):
        model = self.model_box.currentText() or self.settings["model"]
        msgs = self.build_messages(chat)
        self.base_est = self.count_tokens(msgs)
        chat["messages"].append({"role": "assistant", "content": "", "model": model})

        self.old_workers = [w for w in self.old_workers if w.isRunning()]
        self.next_id += 1
        self.active_id = self.next_id
        self.gen_chat = chat
        self.search_worker = None
        opts = {"temperature": self.settings["temperature"],
                "num_ctx": self.settings["num_ctx"]}
        caps = self.get_caps(model)
        think = bool(self.settings["show_thinking"]) if (caps and "thinking" in caps) else None
        w = ChatWorker(self.active_id, model, msgs, opts, self.settings["keep_alive"], think)
        w.token.connect(self.on_token)
        w.thinking.connect(self.on_thinking)
        w.stats.connect(self.on_stats)
        w.usage.connect(self.on_usage)
        w.failed.connect(self.on_failed)
        w.done.connect(self.on_done)
        self.worker = w
        self.set_busy(True)
        self.status.setText("Generating...")
        self.render(force=True, to_bottom=True)
        w.start()

    def set_busy(self, busy):
        self.set_send_mode("stop" if busy else "send")
        self.regen_btn.setEnabled(not busy)
        self.model_box.setEnabled(not busy)
        self.sum_btn.setEnabled(not busy)

    def on_token(self, gid, text):
        if gid != self.active_id or not self.gen_chat:
            return
        self.gen_chat["messages"][-1]["content"] += text
        if self.gen_chat["id"] == self.current_id:
            self.dirty = True

    def on_thinking(self, gid, text):
        if gid != self.active_id or not self.gen_chat:
            return
        m = self.gen_chat["messages"][-1]
        m["thinking"] = m.get("thinking", "") + text
        if self.gen_chat["id"] == self.current_id:
            self.dirty = True

    def on_stats(self, gid, text):
        if gid == self.active_id:
            self.status.setText(text)

    def on_usage(self, gid, total):
        if gid == self.active_id and self.gen_chat is not None:
            self.gen_chat["_usage_pending"] = total

    def on_failed(self, gid, err):
        if gid != self.active_id:
            return
        self.finish_generation()
        self.status.setText(err)

    def on_done(self, gid):
        if gid != self.active_id:
            return
        keep = self.status.text()
        self.finish_generation(extract=True)
        if keep and keep != "Generating...":
            self.status.setText(keep)

    def stop_generation(self):
        if self.search_worker is not None:          # still searching the web
            self.search_token += 1
            self.search_worker = None
            self.set_busy(False)
            self.status.setText("Stopped.")
            self.render(force=True)
            return
        w = self.worker
        if not w:
            return
        w.stop()
        self.old_workers.append(w)
        self.finish_generation()
        self.status.setText("Stopped.")

    def finish_generation(self, extract=False):
        chat = self.gen_chat
        if self.worker and self.worker.isRunning():
            self.old_workers.append(self.worker)
        self.worker = None
        self.active_id = None
        self.gen_chat = None
        reply_ok = False
        if chat:
            msgs = chat["messages"]
            model, ops = None, []
            pending_usage = chat.pop("_usage_pending", None)
            if msgs and msgs[-1]["role"] == "assistant":
                last = msgs[-1]
                model = last.get("model")
                th, ans, _o = split_think(last["content"])
                if th:
                    last["thinking"] = "\n\n".join(x for x in (last.get("thinking", "").strip(), th) if x)
                ops = TAG_RE.findall(ans)
                if ops and self.turn_untrusted(msgs):
                    ops = []         # text from the web / files / code output must not write memory
                last["content"] = strip_tags(ans)
                if ops:
                    self.apply_memory_ops(chat, ops)
                    if not last["content"].strip():
                        last["content"] = "*(Saved to memory.)*"
                if not last["content"].strip():
                    if last.get("thinking", "").strip():
                        last["content"] = "*(The model only produced thinking - try Regenerate.)*"
                    else:
                        msgs.pop()
                if msgs and msgs[-1]["role"] == "assistant" and msgs[-1]["content"].strip():
                    reply_ok = True
            if extract and pending_usage:
                chat["usage"] = pending_usage
                chat["usage_len"] = len(msgs)
            chat["updated"] = time.time()
            self.save_chats()
            # fallback: if the model didn't tag anything, run the extraction pass
            if extract and not ops and self.settings["use_memory"] and self.settings["auto_extract"]:
                last_user = next((m["content"] for m in reversed(msgs) if m["role"] == "user"), "")
                if last_user and model:
                    self.start_extraction(chat, last_user, model)
            if extract and reply_ok:
                self.after_reply(chat, model)
        self.set_busy(False)
        self.status.setText("")
        self.html_cache.clear()
        self.render(force=True)

    @staticmethod
    def turn_untrusted(msgs):
        """True if the reply was based on text that didn't come from the user (web, files, code output)."""
        prev = msgs[-2] if len(msgs) >= 2 else None
        return bool(prev and (prev["role"] == "output" or prev.get("web_ctx")
                              or any(a.get("kind") == "text" for a in prev.get("attachments", []))))

    def after_reply(self, chat, model):
        """Things that happen once after a good reply: title, summary, speech."""
        s = self.settings
        if s["auto_title"] and chat.get("auto_title") and len(chat["messages"]) == 2 and model:
            first = chat["messages"][0]["content"][:400]
            answer = self.msg_parts(chat["messages"][1])[1][:400]
            self.ask("title|" + chat["id"], model, TITLE_PROMPT,
                     f"User: {first}\n\nAssistant: {answer}", {"temperature": 0.2, "num_predict": 20,
                                                              "num_ctx": s["num_ctx"]})
        if s["auto_summary"] and chat.get("usage", 0) >= 0.75 * s["num_ctx"]:
            self.start_summary(chat)
        if s["speak_replies"] and chat["id"] == self.current_id:
            self.speak(self.msg_parts(chat["messages"][-1])[1], len(chat["messages"]) - 1)

    # ------------------------------------------------- background asks
    def ask(self, tag, model, system, user, opts):
        w = AskWorker(tag, model, system, user, opts, self.settings["keep_alive"])
        w.result.connect(self.on_ask_result)
        self.bg_workers = [x for x in self.bg_workers if x.isRunning()]
        self.bg_workers.append(w)
        w.start()

    def on_ask_result(self, tag, text):
        kind, _, rest = tag.partition("|")
        text = (text or "").strip()
        if kind == "facts":
            self.on_extracted(rest, text)
        elif kind == "title":
            chat = next((c for c in self.chats if c["id"] == rest), None)
            title = text.strip().strip("\"'*#. ")[:60]
            if chat and chat.get("auto_title") and 2 <= len(title) and "\n" not in title:
                chat["title"] = title
                chat["auto_title"] = False
                self.refresh_chat_list(self.current_id)
                self.save_chats()
        elif kind == "summary":
            cid, end, rev = rest.split("|")
            chat = next((c for c in self.chats if c["id"] == cid), None)
            if chat and text and chat.get("rev", 0) == int(rev) and len(chat["messages"]) > int(end):
                chat["summary"] = text[:2500]
                chat["summary_upto"] = int(end)
                chat.pop("usage", None)
                self.save_chats()
                self.notify("Older messages were summarized to free up context.")
                self.refresh_meter()
            elif chat is not None and not text:
                self.notify("Couldn't summarize (the model returned nothing).")

    def start_summary(self, chat, manual=False):
        if not chat or self.worker or self.search_worker:
            return
        msgs = chat["messages"]
        upto = chat.get("summary_upto", 0) if chat.get("summary") else 0
        end = len(msgs) - 4
        while end > upto + 1 and msgs[end]["role"] != "user":
            end -= 1
        if end <= upto + 1 or msgs[end]["role"] != "user":
            if manual:
                self.notify("Not enough older messages to summarize yet.")
            return
        seg = []
        for m in msgs[upto:end]:
            who = {"user": "User", "assistant": "Assistant", "output": "Code output"}.get(m["role"], "User")
            body = self.msg_parts(m)[1] if m["role"] == "assistant" else m["content"]
            seg.append(f"{who}: {body[:1500]}")
        prev = chat.get("summary", "") if upto else ""
        user = (f"Previous summary:\n{prev}\n\n" if prev else "") + "New messages:\n" + "\n\n".join(seg)
        model = self.model_box.currentText() or self.settings["model"]
        if manual:
            self.notify("Summarizing older messages...")
        self.ask(f"summary|{chat['id']}|{end}|{chat.get('rev', 0)}", model, SUMMARY_PROMPT,
                 user[:max(2000, int(self.settings["num_ctx"] * 2.2))],
                 {"temperature": 0.2, "num_predict": 400, "num_ctx": self.settings["num_ctx"]})

    # -------------------------------------------------------- memory logic
    def notify(self, text):
        self.statusBar().showMessage(text, 8000)

    def add_memory(self, fact):
        fact = " ".join(fact.split())[:300]
        if len(fact) < 3:
            return False
        low = fact.lower()
        for i, m in enumerate(self.memories):
            ml = m.lower()
            if low in ml:
                return False                     # already known
            if ml in low:
                self.memories[i] = fact          # new fact extends an old one
                return True
        self.memories.append(fact)
        return True

    def forget_memory(self, text):
        t = text.strip().lower()
        if len(t) < 3:
            return 0
        keep = [m for m in self.memories if t not in m.lower()]
        removed = len(self.memories) - len(keep)
        self.memories = keep
        return removed

    def apply_memory_ops(self, chat, ops):
        self.memories = self.mem_load(chat)
        notes = []
        for kind, value in ops:
            if kind.lower() == "memory":
                if self.add_memory(value):
                    notes.append("Remembered: " + " ".join(value.split())[:80])
            else:
                n = self.forget_memory(value)
                if n:
                    notes.append(f"Forgot {n} memory item(s)")
        if notes:
            self.mem_save(chat, self.memories)
            self.notify("; ".join(notes))

    def start_extraction(self, chat, text, model):
        if len(text) < 12 or text.startswith("/"):
            return
        known = "\n".join(f"- {m}" for m in self.mem_load(chat)) or "(nothing yet)"
        opts = {"temperature": 0, "num_predict": 120, "num_ctx": self.settings["num_ctx"]}
        self.ask("facts|" + chat["id"], model, EXTRACT_PROMPT,
                 f"Already known:\n{known}\n\nUser message:\n{text[:1500]}", opts)

    def on_extracted(self, cid, text):
        chat = next((c for c in self.chats if c["id"] == cid), None)
        if not chat:
            return
        self.memories = self.mem_load(chat)
        added = []
        for line in text.splitlines():
            line = line.strip()
            if not line.startswith(("-", "*")):
                continue
            fact = line.lstrip("-* ").strip()
            if fact.lower().strip(". ") in ("none", "nothing", "n/a") or not 3 <= len(fact) <= 200:
                continue
            if self.add_memory(fact):
                added.append(fact)
            if len(added) >= 3:
                break
        if added:
            self.mem_save(chat, self.memories)
            self.notify("Remembered: " + "; ".join(a[:60] for a in added))

    def open_memory_file(self):
        if not MEMORY_FILE.exists():
            save_memories(self.memories if not self.memory_owner(self.current_chat()) else [])
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(MEMORY_FILE)))

    # ------------------------------------------------------ code: save / run
    def save_code(self, lang, code):
        ext = LANG_EXT.get(lang, "txt")
        path, _ = QFileDialog.getSaveFileName(self, "Save code as", f"code.{ext}", "All files (*)")
        if path:
            try:
                Path(path).write_text(code + "\n", encoding="utf-8")
                self.notify(f"Saved {path}")
            except OSError as e:
                QMessageBox.warning(self, "Couldn't save", str(e))

    def run_code(self, chat, code):
        if self.run_worker and self.run_worker.isRunning():
            self.notify("Another snippet is still running.")
            return
        box = QMessageBox(self)
        box.setWindowTitle("Run this code?")
        box.setIcon(QMessageBox.Warning)
        box.setText("This will run the Python code below on your computer, with your user's "
                    "permissions (limit: 30 seconds).\nOnly run code you have read and understand.")
        box.setDetailedText(code)
        run_btn = box.addButton("Run", QMessageBox.AcceptRole)
        cancel_btn = box.addButton("Cancel", QMessageBox.RejectRole)
        box.setDefaultButton(cancel_btn)
        box.exec()
        if box.clickedButton() is not run_btn:
            return
        w = RunWorker(code)
        self.run_chat = chat
        w.result.connect(self.on_run_result)
        self.run_worker = w
        self.notify("Running...")
        w.start()

    def on_run_result(self, out, rc):
        chat = self.run_chat
        if chat is None or chat not in self.chats:
            return
        chat["messages"].append({"role": "output", "content": out, "code": rc})
        chat["updated"] = time.time()
        chat.pop("usage", None)
        self.save_chats()
        self.notify("Finished." if rc == 0 else "Finished with errors.")
        self.render(force=True, to_bottom=chat["id"] == self.current_id)

    # ----------------------------------------------------- voice in / out
    def speak(self, text, idx=None):
        self.stop_speaking()
        text = md_to_plain(text)[:6000]
        if not text:
            return
        f = RUN_DIR / "speak.txt"
        f.write_text(text, encoding="utf-8")
        try:
            if os.name == "nt":
                p = str(f).replace("'", "''")
                cmd = ["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
                       "Add-Type -AssemblyName System.Speech; "
                       "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                       f"$s.Speak((Get-Content -Raw -Encoding UTF8 '{p}'))"]
                self.speak_proc = subprocess.Popen(cmd, creationflags=0x08000000)
            elif sys.platform == "darwin":
                self.speak_proc = subprocess.Popen(["say", "-f", str(f)])
            else:
                exe = "espeak-ng" if subprocess.call(["which", "espeak-ng"], stdout=subprocess.DEVNULL,
                                                      stderr=subprocess.DEVNULL) == 0 else "espeak"
                self.speak_proc = subprocess.Popen([exe, "-f", str(f)])
        except OSError:
            self.speak_proc = None
            self.notify("No text-to-speech engine found on this system.")
            return
        self.speaking_msg = idx
        self.dirty = True
        self.speak_timer.start(500)

    def check_speaking(self):
        if self.speak_proc is None or self.speak_proc.poll() is not None:
            self.speak_timer.stop()
            self.speak_proc = None
            self.speaking_msg = None
            self.dirty = True

    def stop_speaking(self):
        if self.speak_proc is not None:
            try:
                self.speak_proc.terminate()
            except OSError:
                pass
        self.speak_proc = None
        if self.speaking_msg is not None:
            self.speaking_msg = None
            self.dirty = True

    def toggle_mic(self):
        if self.mic_worker and self.mic_worker.isRunning():
            self.mic_worker.stop()
            self.mic_btn.setText("...")
            self.mic_btn.setEnabled(False)
            return
        w = MicWorker()
        w.text.connect(self.on_mic_text)
        w.failed.connect(self.on_mic_failed)
        w.status.connect(self.status.setText)
        w.finished.connect(self.on_mic_finished)
        self.mic_worker = w
        self.mic_btn.setText("Stop")
        self.mic_btn.setProperty("rec", "1")
        self.mic_btn.style().unpolish(self.mic_btn)
        self.mic_btn.style().polish(self.mic_btn)
        self.status.setText("Listening... click Stop when you're done.")
        w.start()

    def on_mic_text(self, text):
        if text:
            cur = self.input.toPlainText()
            self.input.setPlainText((cur + " " + text).strip())
            self.input.moveCursor(QTextCursor.End)
        self.input.setFocus()

    def on_mic_failed(self, err):
        QMessageBox.information(self, "Voice input", err)

    def on_mic_finished(self):
        self.mic_btn.setText("Mic")
        self.mic_btn.setEnabled(True)
        self.mic_btn.setProperty("rec", "0")
        self.mic_btn.style().unpolish(self.mic_btn)
        self.mic_btn.style().polish(self.mic_btn)
        if not self.worker:
            self.status.setText("")

    # ------------------------------------------------------------- actions
    def regenerate(self):
        chat = self.current_chat()
        if self.worker or self.search_worker or not chat:
            return
        if chat["messages"] and chat["messages"][-1]["role"] == "assistant":
            chat["messages"].pop()
        if chat["messages"] and chat["messages"][-1]["role"] in ("user", "output"):
            chat.pop("usage", None)
            self.generate(chat)

    def last_reply_index(self, chat):
        for i in range(len(chat["messages"]) - 1, -1, -1):
            m = chat["messages"][i]
            if m["role"] == "assistant" and m["content"]:
                return i
        return None

    def copy_last(self):
        chat = self.current_chat()
        if not chat:
            return
        i = self.last_reply_index(chat)
        if i is not None:
            QGuiApplication.clipboard().setText(self.msg_parts(chat["messages"][i])[1])
            self.status.setText("Copied.")

    def save_reply_as(self, idx):
        """Save one reply as .md / .txt / .html / .docx."""
        chat = self.current_chat()
        if not chat:
            return
        if idx is None:
            idx = self.last_reply_index(chat)
        if idx is None or not (0 <= idx < len(chat["messages"])):
            self.notify("There's no reply to save yet.")
            return
        text = self.msg_parts(chat["messages"][idx])[1]
        base = re.sub(r"[^\w\- ]+", "", chat["title"])[:30].strip() or "reply"
        path, flt = QFileDialog.getSaveFileName(
            self, "Save reply as", f"{base}.md",
            "Markdown (*.md);;Word document (*.docx);;HTML (*.html);;Text (*.txt)")
        if not path:
            return
        p = Path(path)
        ext = p.suffix.lower()
        if not ext:
            ext = {"Markdown": ".md", "Word": ".docx", "HTML": ".html", "Text": ".txt"}.get(
                flt.split()[0], ".md")
            p = p.with_suffix(ext)
        try:
            if ext == ".docx":
                write_docx(str(p), chat["title"], text)
            elif ext in (".html", ".htm"):
                t = THEMES["light"]
                body, _ = markdown_html(text, t)
                p.write_text(f'<!doctype html><html><head><meta charset="utf-8"><title>{html.escape(chat["title"])}'
                             f'</title></head><body style="font-family:Segoe UI,Arial,sans-serif; max-width:820px; '
                             f'margin:30px auto; line-height:1.5">{body}</body></html>', encoding="utf-8")
            elif ext == ".txt":
                p.write_text(md_to_plain_keep_lines(text), encoding="utf-8")
            else:
                p.write_text(text + "\n", encoding="utf-8")
            self.notify(f"Saved {p}")
        except OSError as e:
            QMessageBox.warning(self, "Couldn't save", str(e))

    def export_chat(self, chat=None):
        chat = chat or self.current_chat()
        if not chat or not chat["messages"]:
            return
        safe = re.sub(r"[^\w\- ]+", "", chat["title"])[:30].strip() or "chat"
        path, _ = QFileDialog.getSaveFileName(self, "Export chat", safe + ".md", "Markdown (*.md)")
        if not path:
            return
        lines = [f"# {chat['title']}\n"]
        for m in chat["messages"]:
            if m["role"] == "user":
                who, body = "You", m["content"]
            elif m["role"] == "output":
                who, body = "Output", "```\n" + m["content"] + "\n```"
            else:
                who, body = m.get("model", "Assistant"), self.msg_parts(m)[1]
            att = "".join(f"\n\n*Attached: {a['name']}*" for a in m.get("attachments", []))
            lines.append(f"**{who}**\n\n{body}{att}\n")
        Path(path).write_text("\n---\n\n".join(lines), encoding="utf-8")
        self.status.setText("Exported.")

    def handle_command(self, text):
        cmd, _, arg = text.partition(" ")
        cmd = cmd.lower()
        arg = arg.strip()
        chat = self.current_chat()
        if cmd == "/remember":
            if arg:
                self.memories = self.mem_load(chat)
                if self.add_memory(arg):
                    self.mem_save(chat, self.memories)
                self.notify("Remembered: " + arg[:80])
            else:
                self.status.setText("Usage: /remember <text>")
            return True
        if cmd == "/forget":
            self.memories = self.mem_load(chat)
            n = self.forget_memory(arg)
            if n:
                self.mem_save(chat, self.memories)
            self.notify(f"Forgot {n} memory item(s)." if n else "Nothing matched.")
            return True
        if cmd == "/memory":
            self.open_memory()
            return True
        if cmd == "/summarize":
            self.start_summary(chat, manual=True)
            return True
        if cmd == "/persona":
            if arg.lower() in ("", "none"):
                i = 0
            else:
                i = next((k for k in range(1, self.persona_box.count())
                          if arg.lower() in self.persona_box.itemText(k).lower()), -1)
            if i < 0:
                self.notify("No persona matches that name.")
            else:
                self.persona_box.setCurrentIndex(i)
            return True
        if cmd == "/clear":
            if chat and not self.worker:
                self.delete_attachment_files(chat)
                chat["messages"].clear()
                chat["forks"] = {}
                for k in ("summary", "summary_upto", "usage"):
                    chat.pop(k, None)
                chat["rev"] = chat.get("rev", 0) + 1
                self.html_cache.clear()
                self.cancel_edit()
                self.save_chats()
                self.render(force=True)
            return True
        if cmd == "/help":
            QMessageBox.information(
                self, "Commands",
                "/remember <text>  - save a long-term memory\n"
                "/forget <text>  - delete matching memories\n"
                "/memory  - view/edit memories\n"
                "/web <question>  - answer using a web search\n"
                "/persona <name>  - switch persona (/persona none to switch off)\n"
                "/summarize  - compress older messages now\n"
                "/clear  - clear this chat\n"
                "/help  - this message\n\n"
                "Enter sends, Shift+Enter adds a new line. Ctrl+/ lists keyboard shortcuts.")
            return True
        return False

    def open_memory(self):
        chat = self.current_chat()
        p = self.memory_owner(chat)
        self.memories = self.mem_load(chat)
        dlg = MemoryDialog(self.memories, self,
                           f"Memory - {p['name']}" if p else "Long-term memory")
        if dlg.exec():
            self.memories = dlg.memories()
            self.mem_save(chat, self.memories)

    def open_settings(self):
        dlg = SettingsDialog(self.settings, self)
        if dlg.exec():
            self.settings.update(dlg.values())
            save_json(SETTINGS_FILE, self.settings)
            self.apply_theme()
            self.render(force=True)

    # --------------------------------------------------------------- close
    def closeEvent(self, event):
        self.stop_speaking()
        for w in (self.mic_worker,):
            if w and w.isRunning():
                w.stop()
        w = self.worker
        if w:
            w.stop()
            self.old_workers.append(w)
        extra = [x for x in (self.search_worker, self.run_worker, self.mic_worker) if x]
        for t in self.old_workers + self.bg_workers + self.unload_workers + extra:
            if not t.wait(3000):
                t.terminate()
                t.wait(500)
        for c in self.chats:
            c.pop("_usage_pending", None)
        self.save_chats()
        save_json(SETTINGS_FILE, self.settings)
        super().closeEvent(event)


def md_to_plain_keep_lines(text):
    """Markdown -> readable plain text, keeping line breaks and code."""
    text = re.sub(r"^```.*$", "", text, flags=re.M)
    text = re.sub(r"\*\*(.+?)\*\*", r"\1", text)
    text = re.sub(r"^#{1,6}\s+", "", text, flags=re.M)
    return text.strip() + "\n"


def install_excepthook():
    """Write unexpected errors to error.log (useful for bug reports) instead of dying silently."""
    log = DATA_DIR / "error.log"
    shown = []

    def hook(exc_type, exc, tb):
        text = "".join(traceback.format_exception(exc_type, exc, tb))
        try:
            with open(log, "a", encoding="utf-8") as f:
                f.write(f"--- {time.strftime('%Y-%m-%d %H:%M:%S')}  Local Chat {__version__}\n{text}\n")
        except OSError:
            pass
        sys.__excepthook__(exc_type, exc, tb)
        if not shown:                                   # one dialog per session, never a flood
            shown.append(1)
            try:
                QMessageBox.critical(
                    None, "Unexpected error",
                    f"Something went wrong:\n\n{exc_type.__name__}: {exc}\n\n"
                    f"Details were saved to:\n{log}\nIf it keeps happening, please report it "
                    "on the project page and attach that file.")
            except Exception:  # noqa: BLE001
                pass

    sys.excepthook = hook


def main():
    if "--version" in sys.argv[1:]:
        print(f"Local Chat {__version__}")
        return
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    install_excepthook()
    win = MainWindow()
    win.show()
    if STARTUP_NOTES:
        QMessageBox.warning(win, "Recovered data", "\n\n".join(STARTUP_NOTES))
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
