# Local Chat

A desktop chat app for running **local LLMs through [Ollama](https://ollama.com)** - a ChatGPT/Claude-style
interface that keeps your chats, memory and files on your own computer. One Python file, built with PySide6.

<!-- Add a screenshot: save it as docs/screenshot.png and uncomment the next line -->
<!-- ![Local Chat](docs/screenshot.png) -->

## Features

- **Chat:** streaming replies, Stop button, many saved chats (pin / rename / delete), search across all chats
- **Edit & resend** any of your messages - old versions stay as branches you can flip between
- **Memory:** a plain-text `memory.md` the model reads and updates itself; recall of relevant older chats
- **Context meter** and automatic summary of older messages when the context window fills up
- **Code blocks:** syntax highlighting, Copy, Save as file, and Run (Python, always asks first)
- **Personas / projects:** saved system prompts with pinned files and optional separate memory
- **Reasoning models:** collapsible "Thought process" (Qwen3, DeepSeek-R1, ...)
- **Web search** (DuckDuckGo, no API key) that can also read the top pages
- **Attachments:** images (vision models), PDF, DOCX, text and code - button, drag & drop, or paste
- **Save replies** as `.md`, `.txt`, `.html` or `.docx`; export whole chats as Markdown
- Read replies aloud, optional voice input, light/dark themes, adjustable text size, keyboard shortcuts
- Unloads the previous model from RAM when you switch models (setting)

## Requirements

- Python **3.9+**
- [Ollama](https://ollama.com/download), running, with at least one model pulled, for example:
  `ollama pull qwen2.5-coder:7b` (text/code) or `ollama pull gemma3:4b` (can also read images)

## Install and run

```bash
git clone <your-repo-url>
cd <your-repo>
python -m venv .venv
# Windows: .venv\Scripts\activate      macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python local_chat.py
```

Optional extras (each unlocks one feature):

| Feature | Install |
|---|---|
| PDF attachments | `pip install pypdf` |
| Voice input (Mic button) | `pip install faster-whisper sounddevice` - the first use downloads a ~150 MB speech model |
| Read aloud | nothing to install on Windows and macOS; on Linux install `espeak-ng` |

## Privacy

Everything stays on your machine, and the app has no telemetry. The only network use besides your Ollama server:

- **Web search** (only when you tick "Search the web" or use `/web`): your question is sent to DuckDuckGo, and the top
  two result pages are downloaded. Untick "Web search also reads the top 2 result pages" in Settings to use snippets only.
- **Voice input:** the speech model is downloaded once from the faster-whisper project.

Your data lives in `~/.local_chat` (chats, memory, personas, settings, attachments). Set `LOCAL_CHAT_DIR` to move it
and `OLLAMA_URL` to use an Ollama server on another machine, e.g. `OLLAMA_URL=http://192.168.1.20:11434`.

## Safety notes

- **Run button:** it runs the Python code from a reply on your computer with your user's permissions - not sandboxed,
  30-second limit. It always shows the code and asks first. Turn it off in Settings -> Features.
- **Memory is protected from outside text:** if a reply was based on web pages, attached files or code output, any
  attempt to write to the memory file from that reply is ignored.

## Tips for modest hardware

- A 3B-8B model in 4-bit (the Ollama default) runs on a 16 GB laptop, even without a GPU.
- Larger "Context size" in Settings means more RAM and slower replies. 4096 is a good start.
- Switching models frees the previous one from RAM automatically; "Keep model in RAM" controls how long a model stays loaded.
- Images need a vision model (for example `gemma3`); the app tells you if the selected model can't read them.

## Commands and shortcuts

`/remember <text>`, `/forget <text>`, `/memory`, `/web <question>`, `/persona <name>`, `/summarize`, `/clear`, `/help`

| Key | Action | Key | Action |
|---|---|---|---|
| Ctrl+N | New chat | Ctrl+K / Ctrl+F | Search chats |
| Ctrl+L | Message box | Esc | Stop / cancel edit / stop speaking |
| Ctrl+R | Regenerate | Ctrl+Shift+C | Copy last reply |
| Ctrl+Shift+S | Save last reply | Ctrl+E | Export chat |
| Ctrl+Shift+W | Toggle web search | Ctrl+Shift+P | Personas |
| Ctrl+, | Settings | Ctrl+T | Light / dark |
| Ctrl+= / Ctrl+- | Text size | Ctrl+/ | List shortcuts |

## Troubleshooting

- **"Can't reach Ollama":** start Ollama (open the app or run `ollama serve`), then press Refresh.
- **Model list is empty:** pull a model, for example `ollama pull qwen2.5-coder:7b`.
- **Web search finds nothing:** it reads DuckDuckGo's public HTML page, which can change or rate-limit. Try again later.
- **Something broke:** details are written to `~/.local_chat/error.log` - please attach it when you open an issue.
- If a data file is ever unreadable, a copy is saved next to it as `*.corrupt-<date>` and the app starts fresh.

## Contributing

Issues and pull requests are welcome. The app is a single file, `local_chat.py`.

## License

MIT - see [LICENSE](LICENSE).
